export const all_routes = {
  dashboard: "/",
  summries: "/summaries",
  phase3: "/phase3/:id",
  dynamictable: "/dynamictable/:id",
  graphical: "/graphicalRepresentation",
  dynamicpage: "/RepOpt/:id",
  dynamiclist: "/RepList/:id",
  schemes:"/schemes_display"

};
