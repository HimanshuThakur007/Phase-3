// Pase3DynamicTable.tsx
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import Wrapper from "../../common/uicomponent/wrapper";
import GridTable from "../../common/component/GridTable";
import { toTitleCase } from "./helperfunc";
import { useSelector, useDispatch } from "react-redux";
import CenteredLoader from "../../common/component/CenteredLoader";
import ReusableModal from "../../common/component/ReusableModal";
import { closeModal, openModal } from "../../redux/modalSlice";
import {
  saveScheme,
  removeSavedSchemeByItemCode,
} from "../../redux/phase3Slice";
import { FormProvider, useForm } from "react-hook-form";
import { renderField } from "../../common/utils/renderField";
import scheme, { display } from "../../core/json/scheme";
import useSchemeOptions, { Option } from "./useSchemeOptions";

const Pase3DynamicTable: React.FC = () => {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const modalOpen = useSelector((s: any) => s.modal.isOpen);
  const modalConfig = useSelector((s: any) => s.modal.config);
  const savedSchemes = useSelector((s: any) => s.phase3.savedSchemes ?? []);

  const selectedDepartment = (location.state as any)?.department ?? "";
  const selectedBranch = (location.state as any)?.branchCode ?? "";
  const itemCodeFromState = (location.state as any)?.itemCode ?? "";

  const {
    data: detailData = [],
    loading,
    error,
  } = useSelector(
    (state: any) =>
      state.reportDetail || { data: [], loading: false, error: null }
  );

  const [tableHeight, setTableHeight] = React.useState("550px");
  const { getSchemeTypes, getSchemeGroups } = useSchemeOptions();
  // const { setValue, watch } = useFormContext();
  const [schemeTypes, setSchemeTypes] = useState<Option[]>([]);
  const [schemeGroups, setSchemeGroups] = useState<Option[]>([]);
  const [loadingTypes, setLoadingTypes] = useState(true);
  const [loadingGroups, setLoadingGroups] = useState(false);

  const form = useForm<any>({
    mode: "onBlur",
    defaultValues: {
      startDate: null,
      endDate: null,
      schemeType: null,
      schemeGroup: null,
      displayType: null,
    },
  });
  const selectedSchemeType = form.watch("schemeType");
  useEffect(() => {
    const loadTypes = async () => {
      setLoadingTypes(true);
      const res = await getSchemeTypes();
      if (res?.status === "ok") {
        setSchemeTypes(res.data);
      }
      setLoadingTypes(false);
    };
    loadTypes();
  }, [getSchemeTypes]);

  // Load Scheme Groups when schemeType changes
  useEffect(() => {
    if (!selectedSchemeType) {
      setSchemeGroups([]);
      form.setValue("schemeGroup", null);
      return;
    }

    const loadGroups = async () => {
      setLoadingGroups(true);
      const value = selectedSchemeType.value;
      const res = await getSchemeGroups(value);
      console.log("res", res);
      if (res?.status === "ok") {
        setSchemeGroups(res.data);
      } else {
        setSchemeGroups([]);
      }
      setLoadingGroups(false);
      form.setValue("schemeGroup", null); // reset
    };

    loadGroups();
  }, [selectedSchemeType, getSchemeGroups, form.setValue]);

  const selectOptions = useMemo(
    () => ({
      schemeType: schemeTypes,
      schemeGroup: schemeGroups,
      displayType: [
        { value: "Send Shelf Picture", label: "Send Shelf Picture" },
      ],
    }),
    [schemeTypes, schemeGroups, selectedSchemeType]
  );

  const renderFieldWrapper = useCallback(
    (field: any, key: string) =>
      renderField({
        field,
        form,
        options: field.props?.name
          ? selectOptions[field.props.name as keyof typeof selectOptions] || []
          : [],
        key,
      }),
    [form, selectOptions]
  );

  // -----------------------------------------------------------------
  //  Normalisation helpers – identical to Phase3Page
  // -----------------------------------------------------------------
  const getItemCodeFromRow = useCallback((row: any): string | undefined => {
    if (!row) return undefined;
    const raw =
      row?.["Item Code"] ??
      row?.itemCode ??
      row?.ItemCode ??
      row?.item_code ??
      row?.Item_Code ??
      row?.itemcode ??
      undefined;
    if (raw === undefined || raw === null) return undefined;
    const trimmed = String(raw).trim();
    return trimmed === "" ? undefined : trimmed;
  }, []);

  const getBranchCodeFromRow = useCallback(
    (row: any): string | undefined => {
      if (selectedBranch && String(selectedBranch).trim() !== "") {
        return String(selectedBranch).trim(); // navigation state wins
      }
      if (!row) return undefined;
      const raw =
        row?.branchCode ??
        row?.Branch_Code ??
        row?.BranchCode ??
        row?.branch_code ??
        row?.branch ??
        row?.Branch ??
        undefined;
      if (raw === undefined || raw === null) return undefined;
      const trimmed = String(raw).trim();
      return trimmed === "" ? undefined : trimmed;
    },
    [selectedBranch]
  );

  const findSavedEntryForRow = useCallback(
    (row: any) => {
      const itemCode = getItemCodeFromRow(row);
      const branchCode = getBranchCodeFromRow(row);
      if (itemCode) {
        if (branchCode) {
          return savedSchemes.find(
            (s: any) =>
              String(s.itemCode ?? "")
                .trim()
                .toLowerCase() === String(itemCode).trim().toLowerCase() &&
              String(s.branchCode ?? "")
                .trim()
                .toLowerCase() === String(branchCode).trim().toLowerCase()
          );
        }
        const global = savedSchemes.find(
          (s: any) =>
            String(s.itemCode ?? "")
              .trim()
              .toLowerCase() === String(itemCode).trim().toLowerCase() &&
            (s.branchCode === undefined || s.branchCode === null)
        );
        return global;
      }
      // deep-equality fallback (rare)
      try {
        const rowJson = JSON.stringify(row || {});
        return savedSchemes.find((s: any) => {
          try {
            return JSON.stringify(s.data) === rowJson;
          } catch {
            return false;
          }
        });
      } catch {
        return undefined;
      }
    },
    [savedSchemes, getItemCodeFromRow, getBranchCodeFromRow]
  );

  // -----------------------------------------------------------------
  //  TOTAL CALCULATIONS (unchanged)
  // -----------------------------------------------------------------
  const totals = useMemo(() => {
    if (!detailData?.length) {
      return {
        totalSiteQty: 0,
        totalSaleQty: 0,
        totalSaleVal: 0,
        totalStockValue: 0,
      };
    }

    return detailData.reduce(
      (acc: any, row: any) => {
        const siteQty = row.total_site_qty ?? row.Site_Qtys ?? 0;
        acc.totalSiteQty += typeof siteQty === "number" ? siteQty : 0;

        const saleQty = row.Total_Sale_Qty ?? row.total_sale_qty ?? 0;
        acc.totalSaleQty += typeof saleQty === "number" ? saleQty : 0;

        const saleVal = row.Total_Sale_Val ?? row.total_sale_val ?? 0;
        acc.totalSaleVal += typeof saleVal === "number" ? saleVal : 0;

        const stockVal =
          row.Str_Stk_Sp_Value ??
          row.str_stk_sp_value ??
          row.total_str_stk_sp_value ??
          0;
        acc.totalStockValue += typeof stockVal === "number" ? stockVal : 0;

        return acc;
      },
      {
        totalSiteQty: 0,
        totalSaleQty: 0,
        totalSaleVal: 0,
        totalStockValue: 0,
      }
    );
  }, [detailData]);

  // -----------------------------------------------------------------
  //  BASE COLUMNS (dynamic)
  // -----------------------------------------------------------------
  const baseColumnDefs = useMemo(() => {
    if (!detailData?.length) return [];
    const first = detailData[0];
    const keys = Object.keys(first);
    const seen = new Set<string>();

    return keys
      .filter((k) => {
        const lower = k.toLowerCase();
        if (
          lower.includes("item") &&
          (lower.includes("code") || lower.includes("name"))
        ) {
          if (seen.has("item_code") || seen.has("item_name")) return false;
          if (lower.includes("code")) seen.add("item_code");
          if (lower.includes("name")) seen.add("item_name");
        }
        return true;
      })
      .map((k) => ({
        field: k,
        headerName: toTitleCase(k),
        filter:
          typeof first[k] === "string"
            ? "agTextColumnFilter"
            : "agNumberColumnFilter",
        headerClass: "bg-royal-blue text-white",
        sortable: true,
        resizable: true,
      }));
  }, [detailData]);

  // -----------------------------------------------------------------
  //  DISPLAYED COLUMNS – add Scheme / Display only on item view
  // -----------------------------------------------------------------
  const displayedColumnDefs = useMemo(() => {
    const cols: any = [...baseColumnDefs];

    if (id !== "2") return cols; // only item-level gets the extra columns

    // ---------- Scheme Column ----------
    cols.push({
      field: "Scheme",
      headerName: "Scheme",
      sortable: false,
      resizable: true,
      pinned: "right",
      filter: false,
      lockPosition: false,
      width: 130,
      cellRenderer: (params: any) => {
        const row = params?.data;
        if (!row) return null;

        const savedEntry = findSavedEntryForRow(row);
        const hasAppliedScheme = !!savedEntry?.data?.appliedScheme;

        const openSchemeModal = () => {
          const preset = savedEntry?.data?.appliedScheme ?? {
            startDate: null,
            endDate: null,
            schemeType: null,
            schemeGroup: null,
          };
          form.reset(preset);

          dispatch(
            openModal({
              title: "Apply New Scheme",
              size: "lg",
              content: (
                <FormProvider {...form}>
                  <form onSubmit={form.handleSubmit(() => {})}>
                    <div className="mb-4 p-3 bg-light rounded border">
                      <div className="d-flex align-items-center mb-2">
                        <div className="me-3 p-2 bg-white rounded border flex-grow-1">
                          <small className="text-muted d-block">
                            Item Code
                          </small>
                          <strong className="text-primary">
                            {getItemCodeFromRow(row) || "N/A"}
                          </strong>
                        </div>
                        <div className="p-2 bg-white rounded border flex-grow-2">
                          <small className="text-muted d-block">
                            Item Name
                          </small>
                          <strong className="text-primary">
                            {row["Item Name"] ??
                              row.item_name ??
                              row.Item_Name ??
                              "N/A"}
                          </strong>
                        </div>
                        <div className="ms-3 p-2 bg-white rounded border">
                          <small className="text-muted d-block">Branch</small>
                          <strong className="text-primary">
                            {getBranchCodeFromRow(row) || "Global"}
                          </strong>
                        </div>
                      </div>
                    </div>

                    <div className="row">
                      {Object.entries(scheme.properties).map(([key, field]) => (
                        <div key={key} className="col-lg-6 col-md-6 mb-3">
                          {renderFieldWrapper(field as any, key)}
                        </div>
                      ))}
                    </div>
                  </form>
                </FormProvider>
              ),
              footerButtons: [
                {
                  label: "Close",
                  variant: "secondary",
                  onClick: () => dispatch(closeModal()),
                },
                {
                  label: "Save",
                  variant: "primary",
                  onClick: () =>
                    form.handleSubmit((data: any) => {
                      const existing = findSavedEntryForRow(row);
                      const payload = {
                        ...(existing?.data?.appliedDisplay
                          ? { appliedDisplay: existing.data.appliedDisplay }
                          : {}),
                        appliedScheme: data,
                      };
                      dispatch(
                        saveScheme({
                          row: {
                            ...row,
                            itemCode: getItemCodeFromRow(row),
                            branchCode: getBranchCodeFromRow(row),
                          },
                          scheme: payload,
                        })
                      );
                      dispatch(closeModal());
                    })(),
                },
              ],
            })
          );
        };

        const removeScheme = () => {
          const itemCode = getItemCodeFromRow(row);
          const branchCode = getBranchCodeFromRow(row);
          const existing = findSavedEntryForRow(row);
          if (!existing) return;

          const newData = { ...existing.data };
          delete newData.appliedScheme;

          const hasOtherKeys = Object.keys(newData).some(
            (k) => k !== "Item Code" && k !== "item_code" && k !== "ItemCode"
          );

          if (hasOtherKeys) {
            dispatch(
              saveScheme({
                row: { ...row, itemCode, branchCode },
                scheme: newData,
              })
            );
          } else if (itemCode) {
            dispatch(
              removeSavedSchemeByItemCode(
                branchCode ? { itemCode, branchCode } : itemCode
              )
            );
          }
        };

        if (hasAppliedScheme) {
          return (
            <div className="d-flex align-items-center gap-2">
              <span className="badge bg-success text-white px-3 py-2">
                Applied
              </span>
              <button
                type="button"
                className="btn btn-sm btn-outline-danger p-1"
                title="Remove scheme"
                onClick={(e) => {
                  e.stopPropagation();
                  removeScheme();
                }}
              >
                ×
              </button>
            </div>
          );
        }

        return (
          <button
            className="btn btn-sm btn-outline-primary"
            onClick={(e) => {
              e.stopPropagation();
              openSchemeModal();
            }}
            type="button"
          >
            Apply
          </button>
        );
      },
    });

    // ---------- Display Column ----------
    cols.push({
      field: "Display",
      headerName: "Display",
      sortable: false,
      resizable: true,
      pinned: "right",
      filter: false,
      lockPosition: false,
      width: 130,
      cellRenderer: (params: any) => {
        const row = params?.data;
        if (!row) return null;

        const savedEntry = findSavedEntryForRow(row);
        const hasAppliedDisplay = !!savedEntry?.data?.appliedDisplay;

        const openDisplayModal = () => {
          const preset = savedEntry?.data?.appliedDisplay ?? {
            displayType: null,
          };
          form.reset(preset);

          dispatch(
            openModal({
              title: "Display",
              size: "lg",
              content: (
                <FormProvider {...form}>
                  <form onSubmit={form.handleSubmit(() => {})}>
                    <div className="mb-4 p-3 bg-light rounded border">
                      <div className="d-flex align-items-center mb-2">
                        <div className="me-3 p-2 bg-white rounded border flex-grow-1">
                          <small className="text-muted d-block">
                            Item Code
                          </small>
                          <strong className="text-primary">
                            {getItemCodeFromRow(row) || "N/A"}
                          </strong>
                        </div>
                        <div className="p-2 bg-white rounded border flex-grow-2">
                          <small className="text-muted d-block">
                            Item Name
                          </small>
                          <strong className="text-primary">
                            {row["Item Name"] ??
                              row.item_name ??
                              row.Item_Name ??
                              "N/A"}
                          </strong>
                        </div>
                        <div className="ms-3 p-2 bg-white rounded border">
                          <small className="text-muted d-block">Branch</small>
                          <strong className="text-primary">
                            {getBranchCodeFromRow(row) || "Global"}
                          </strong>
                        </div>
                      </div>
                    </div>

                    <div className="row">
                      {Object.entries(display.properties).map(
                        ([key, field]) => (
                          <div key={key} className="col-lg-12 col-md-12 mb-3">
                            {renderFieldWrapper(field as any, key)}
                          </div>
                        )
                      )}
                    </div>
                  </form>
                </FormProvider>
              ),
              footerButtons: [
                {
                  label: "Close",
                  variant: "secondary",
                  onClick: () => dispatch(closeModal()),
                },
                {
                  label: "Save",
                  variant: "primary",
                  onClick: () =>
                    form.handleSubmit((data: any) => {
                      const existing = findSavedEntryForRow(row);
                      const payload = {
                        ...(existing?.data?.appliedScheme
                          ? { appliedScheme: existing.data.appliedScheme }
                          : {}),
                        appliedDisplay: data,
                      };
                      dispatch(
                        saveScheme({
                          row: {
                            ...row,
                            itemCode: getItemCodeFromRow(row),
                            branchCode: getBranchCodeFromRow(row),
                          },
                          scheme: payload,
                        })
                      );
                      dispatch(closeModal());
                    })(),
                },
              ],
            })
          );
        };

        const removeDisplay = () => {
          const itemCode = getItemCodeFromRow(row);
          const branchCode = getBranchCodeFromRow(row);
          const existing = findSavedEntryForRow(row);
          if (!existing) return;

          const newData = { ...existing.data };
          delete newData.appliedDisplay;

          const hasOtherKeys = Object.keys(newData).some(
            (k) => k !== "Item Code" && k !== "item_code" && k !== "ItemCode"
          );

          if (hasOtherKeys) {
            dispatch(
              saveScheme({
                row: { ...row, itemCode, branchCode },
                scheme: newData,
              })
            );
          } else if (itemCode) {
            dispatch(
              removeSavedSchemeByItemCode(
                branchCode ? { itemCode, branchCode } : itemCode
              )
            );
          }
        };

        if (hasAppliedDisplay) {
          return (
            <div className="d-flex align-items-center gap-2">
              <span className="badge bg-success text-white px-3 py-2">
                Applied
              </span>
              <button
                type="button"
                className="btn btn-sm btn-outline-danger p-1"
                title="Remove display"
                onClick={(e) => {
                  e.stopPropagation();
                  removeDisplay();
                }}
              >
                ×
              </button>
            </div>
          );
        }

        return (
          <button
            className="btn btn-sm btn-outline-secondary"
            onClick={(e) => {
              e.stopPropagation();
              openDisplayModal();
            }}
            type="button"
          >
            Apply
          </button>
        );
      },
    });

    return cols;
  }, [
    baseColumnDefs,
    id,
    dispatch,
    form,
    findSavedEntryForRow,
    getItemCodeFromRow,
    getBranchCodeFromRow,
    renderFieldWrapper,
  ]);

  // -----------------------------------------------------------------
  //  RESPONSIVE HEIGHT
  // -----------------------------------------------------------------
  useEffect(() => {
    const calculateTableHeight = () => {
      const windowHeight = window.innerHeight;
      const windowWidth = window.innerWidth;
      const headerHeight = 100;
      const footerHeight = 30;
      const bottomSpace = 50;
      const minHeight = 400;
      const tabletMinWidth = 768;
      const tabletMaxWidth = 1024;
      let calculatedHeight: number;

      if (windowWidth >= 1200) {
        calculatedHeight =
          windowHeight - headerHeight - footerHeight - bottomSpace;
      } else if (
        windowWidth >= tabletMinWidth &&
        windowWidth <= tabletMaxWidth
      ) {
        const tabletAdjustment = windowWidth < 900 ? 150 : 100;
        calculatedHeight =
          windowHeight - headerHeight - footerHeight - tabletAdjustment;
      } else {
        calculatedHeight = windowHeight - headerHeight - footerHeight - 100;
      }

      setTableHeight(`${Math.max(calculatedHeight, minHeight)}px`);
    };

    calculateTableHeight();
    window.addEventListener("resize", calculateTableHeight);
    window.addEventListener("orientationchange", calculateTableHeight);
    return () => {
      window.removeEventListener("resize", calculateTableHeight);
      window.removeEventListener("orientationchange", calculateTableHeight);
    };
  }, []);

  // -----------------------------------------------------------------
  //  DRILL-DOWN
  // -----------------------------------------------------------------
  const handleDrillDown = (e: any) => {
    if (id === "2") return;
    const code =
      e?.data?.Item_Code ?? e?.data?.item_code ?? e?.data?.["Item Code"] ?? "";
    if (code) {
      navigate("/dynamictable/2", { state: { itemCode: code } });
    }
  };

  const heading = selectedDepartment
    ? `Department: ${selectedDepartment}`
    : selectedBranch
    ? `Branch: ${selectedBranch}`
    : `ItemCode: ${itemCodeFromState}`;

  // -----------------------------------------------------------------
  //  RENDER
  // -----------------------------------------------------------------
  return (
    <Wrapper
      header={`Phase 3 – ${heading}`}
      subHeader="Detail Report"
      ExportR={1}
      backButtonName="Back"
    >
      <>
        {loading && <CenteredLoader />}
        {error && <div className="alert alert-danger">{error}</div>}

        {!loading && !error && (
          <>
            {/* Summary Badges */}
            {detailData.length > 0 && (
              <div className="d-flex flex-wrap gap-2 mb-1 align-items-center">
                {Object.entries({
                  "Site Qty": totals.totalSiteQty,
                  "Sale Qty": totals.totalSaleQty,
                  "Sale Value": totals.totalSaleVal,
                  "Sp Value": totals.totalStockValue,
                }).map(([label, value]) => {
                  const cleanValue = Math.floor(Number(value));
                  const displayValue = cleanValue.toLocaleString("en-IN");
                  return (
                    <span
                      key={label}
                      className="badge bg-light text-dark border px-3 py-2 fw-medium"
                      style={{ fontSize: "0.875rem" }}
                      title={label}
                    >
                      <strong>{label}:</strong> {displayValue}
                    </span>
                  );
                })}
              </div>
            )}

            {/* Table */}
            {detailData.length > 0 ? (
              <GridTable
                rowData={detailData}
                columnDefs={displayedColumnDefs}
                enableEditing={false}
                enableSelection={false}
                height={tableHeight}
                onRowClick={handleDrillDown}
                reportHeader={`Phase_3_${heading}_Summary`}
              />
            ) : (
              <div className="text-center py-4 text-muted">
                No data available for the selected view.
              </div>
            )}
          </>
        )}

        {/* Modal */}
        <ReusableModal
          isOpen={modalOpen}
          onClose={() => dispatch(closeModal())}
          title={modalConfig?.title}
          size={modalConfig?.size}
          centered={modalConfig?.centered}
          closeButton={modalConfig?.closeButton}
          footerButtons={modalConfig?.footerButtons}
          backdrop={modalConfig?.backdrop}
        >
          {modalConfig?.content}
        </ReusableModal>
      </>
    </Wrapper>
  );
};

export default Pase3DynamicTable;
