

const SalesDashboard = () => {
    return (
        <div>SalesDashboard</div>
    )
}

export default SalesDashboard