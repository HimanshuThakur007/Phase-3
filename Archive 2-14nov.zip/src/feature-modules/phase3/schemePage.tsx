// // Pase3DynamicTable.tsx
// import React, { useEffect, useMemo, useCallback } from "react";
// import { useNavigate } from "react-router-dom";
// import Wrapper from "../../common/uicomponent/wrapper";
// import GridTable from "../../common/component/GridTable";
// import { toTitleCase } from "./helperfunc";
// import { useSelector, useDispatch } from "react-redux";
// import CenteredLoader from "../../common/component/CenteredLoader";
// import {
//   removeSavedSchemeByItemCode,
//   clearSavedSchemes,
//   saveScheme,
// } from "../../redux/phase3Slice";
// import moment from "moment";

// const SchemePage: React.FC = () => {
//   const dispatch = useDispatch();
//   const navigate = useNavigate();

//   // local responsive table height (keeps your logic)
//   const [tableHeight, setTableHeight] = React.useState("550px");

//   useEffect(() => {
//     const calculateTableHeight = () => {
//       const windowHeight = window.innerHeight;
//       const windowWidth = window.innerWidth;
//       const headerHeight = 100;
//       const footerHeight = 30;
//       const bottomSpace = 50;
//       const minHeight = 400;
//       const tabletMinWidth = 768;
//       const tabletMaxWidth = 1024;
//       let calculatedHeight: number;

//       if (windowWidth >= 1200) {
//         calculatedHeight =
//           windowHeight - headerHeight - footerHeight - bottomSpace;
//       } else if (
//         windowWidth >= tabletMinWidth &&
//         windowWidth <= tabletMaxWidth
//       ) {
//         const tabletAdjustment = windowWidth < 900 ? 150 : 100;
//         calculatedHeight =
//           windowHeight - headerHeight - footerHeight - tabletAdjustment;
//       } else {
//         calculatedHeight = windowHeight - headerHeight - footerHeight - 100;
//       }

//       setTableHeight(`${Math.max(calculatedHeight, minHeight)}px`);
//     };

//     calculateTableHeight();
//     window.addEventListener("resize", calculateTableHeight);
//     window.addEventListener("orientationchange", calculateTableHeight);
//     return () => {
//       window.removeEventListener("resize", calculateTableHeight);
//       window.removeEventListener("orientationchange", calculateTableHeight);
//     };
//   }, []);

//   // --- Redux selectors ---
//   // expects phase3.savedSchemes = [{ itemCode?, data, savedAt }, ...]
//   const savedSchemes = useSelector(
//     (state: any) => state.phase3?.savedSchemes ?? []
//   );
//   console.log("savedSchemes", savedSchemes);
//   const loading = useSelector((state: any) => state.phase3?.loading ?? false);
//   const activeTab = useSelector(
//     (state: any) => state.phase3?.activeTab ?? "department"
//   );

//   const rowData = useMemo(() => {
//     return savedSchemes.map((s: any, idx: number) => {
//       // Format dates using moment
//       const formattedStartDate = s.data?.startDate
//         ? moment(s.data.startDate).format("DD-MM-YYYY")
//         : "";
//       const formattedEndDate = s.data?.endDate
//         ? moment(s.data.endDate).format("DD-MM-YYYY")
//         : "";

//       return {
//         __savedIndex: idx,
//         itemCode: s.itemCode,
//         "Branch Code": s.data?.branchCode || "",
//         Stock: s.data?.["Str Stk"] || 0,
//         "Old Scheme Type": s.data?.["Scheme Type"],
//         "Old Scheme Group": s.data?.["Scheme Group"],
//         "Scheme Type": s.data?.schemeType?.value || "",
//         "Scheme Group": s.data?.schemeGroup?.value || "",
//         "Scheme Start Date": formattedStartDate,
//         "Scheme End Date": formattedEndDate,
//         "Display Type": s.data?.displayType?.value || "",
//       };
//     });
//   }, [savedSchemes]);

//   // -------------------
//   // delete handler must be defined BEFORE columnDefs
//   // -------------------
//   const onDeleteRow = useCallback(
//     (row: any) => {
//       if (!row) return;
//       const itemCode = row.itemCode;
//       const confirmMsg = itemCode
//         ? `Delete saved scheme for Item Code "${itemCode}"?`
//         : `Delete this saved scheme?`;
//       if (!window.confirm(confirmMsg)) return;

//       if (itemCode) {
//         dispatch(removeSavedSchemeByItemCode(itemCode));
//         return;
//       }
//       if (row.savedAt) {
//         const remaining = (savedSchemes || []).filter(
//           (s: any) => s.savedAt !== row.savedAt
//         );

//         dispatch(clearSavedSchemes());
//         remaining.forEach((s: any) => {
//           dispatch(saveScheme({ row: s.data, scheme: {} }));
//         });
//         return;
//       }

//       console.warn("Unable to delete row: no itemCode or savedAt found.");
//     },
//     [dispatch, savedSchemes]
//   );

//   // build columnDefs dynamically from the first row's keys (excluding internal keys)
//   const columnDefs = useMemo(() => {
//     if (!rowData || rowData.length === 0) {
//       // minimal default columns
//       return [
//         // {
//         //   headerName: "Item Code",
//         //   field: "itemCode",
//         //   sortable: true,
//         //   filter: true,
//         // },
//         // { headerName: "Saved At", field: "savedAt", sortable: true },
//         {
//           headerName: "Actions",
//           field: "actions",
//           cellRenderer: (params: any) => {
//             return (
//               <div style={{ display: "flex", gap: 8 }}>
//                 <button
//                   onClick={(e) => {
//                     e.stopPropagation();
//                     onDeleteRow(params.data);
//                   }}
//                   className="btn btn-sm btn-primary"
//                   title="Delete"
//                 >
//                   Delete
//                 </button>
//               </div>
//             );
//           },
//           pinned: "right",
//           width: 120,
//         },
//       ];
//     }

//     // get all keys from first row
//     const keys = Object.keys(rowData[0]).filter(
//       (k) => !["__savedIndex"].includes(k)
//     );

//     const cols = keys
//       .filter((k) => k !== "actions")
//       .map((key) => {
//         const headerName = toTitleCase(String(key).replace(/_/g, " "));
//         const base: any = {
//           headerName,
//           field: key,
//           sortable: true,
//           filter: true,
//           resizable: true,
//         };
//         if (key === "savedAt") base.width = 180;
//         if (key === "itemCode") base.width = 160;
//         return base;
//       });

//     // append actions column
//     cols.push({
//       headerName: "Actions",
//       field: "actions",
//       cellRenderer: (params: any) => {
//         return (
//           <div style={{ display: "flex", gap: 8 }}>
//             <button
//               onClick={(e) => {
//                 e.stopPropagation();
//                 onDeleteRow(params.data);
//               }}
//               className="btn btn-sm btn-danger"
//               title="Delete"
//             >
//               Delete
//             </button>
//           </div>
//         );
//       },
//       pinned: "right",
//       width: 120,
//     });

//     return cols;
//   }, [rowData, onDeleteRow]);

//   const heading = toTitleCase(String(activeTab || "schemes"));

//   return (
//     <Wrapper
//       header="Scheme And Display"
//       subHeader="Applied Schemes & Display"
//       ExportR={1}
//       backButtonName="Back"
//     >
//       {loading ? (
//         <CenteredLoader />
//       ) : (
//         <GridTable
//           rowData={rowData}
//           columnDefs={columnDefs}
//           enableEditing={false}
//           enableSelection={false}
//           height={tableHeight}
//           reportHeader={`Phase_3_${heading}_Summary`}
//         />
//       )}
//     </Wrapper>
//   );
// };

// export default SchemePage;

// Pase3DynamicTable.tsx
import React, { useEffect, useMemo, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Wrapper from "../../common/uicomponent/wrapper";
import GridTable from "../../common/component/GridTable";
import { toTitleCase } from "./helperfunc";
import { useSelector, useDispatch } from "react-redux";
import CenteredLoader from "../../common/component/CenteredLoader";
import {
  removeSavedSchemeByItemCode,
  clearSavedSchemes,
  saveScheme,
} from "../../redux/phase3Slice";
import moment from "moment";

const SchemePage: React.FC = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  // local responsive table height (keeps your logic)
  const [tableHeight, setTableHeight] = React.useState("550px");

  useEffect(() => {
    const calculateTableHeight = () => {
      const windowHeight = window.innerHeight;
      const windowWidth = window.innerWidth;
      const headerHeight = 100;
      const footerHeight = 30;
      const bottomSpace = 50;
      const minHeight = 400;
      const tabletMinWidth = 768;
      const tabletMaxWidth = 1024;
      let calculatedHeight: number;

      if (windowWidth >= 1200) {
        calculatedHeight =
          windowHeight - headerHeight - footerHeight - bottomSpace;
      } else if (
        windowWidth >= tabletMinWidth &&
        windowWidth <= tabletMaxWidth
      ) {
        const tabletAdjustment = windowWidth < 900 ? 150 : 100;
        calculatedHeight =
          windowHeight - headerHeight - footerHeight - tabletAdjustment;
      } else {
        calculatedHeight = windowHeight - headerHeight - footerHeight - 100;
      }

      setTableHeight(`${Math.max(calculatedHeight, minHeight)}px`);
    };

    calculateTableHeight();
    window.addEventListener("resize", calculateTableHeight);
    window.addEventListener("orientationchange", calculateTableHeight);
    return () => {
      window.removeEventListener("resize", calculateTableHeight);
      window.removeEventListener("orientationchange", calculateTableHeight);
    };
  }, []);

  // --- Redux selectors ---
  // expects phase3.savedSchemes = [{ itemCode?, branchCode?, data, savedAt }, ...]
  const savedSchemes = useSelector(
    (state: any) => state.phase3?.savedSchemes ?? []
  );
  console.log("savedSchemes", savedSchemes);
  const loading = useSelector((state: any) => state.phase3?.loading ?? false);
  const activeTab = useSelector(
    (state: any) => state.phase3?.activeTab ?? "department"
  );

  // small helper to normalize branch code read from our rowData
  const normalizeBranchFromRow = useCallback((row: any): string | undefined => {
    if (!row) return undefined;
    const raw =
      row["Branch Code"] ??
      row.Branch_Code ??
      row.branchCode ??
      row.branch ??
      "";
    const trimmed = String(raw ?? "").trim();
    return trimmed === "" ? undefined : trimmed;
  }, []);

  // const rowData = useMemo(() => {
  //   return savedSchemes.map((s: any, idx: number) => {
  //     // Format dates using moment
  //     const formattedStartDate = s.data?.appliedScheme?.startDate
  //       ? moment(s.data?.appliedScheme?.startDate).format("DD-MM-YYYY")
  //       : "";
  //     const formattedEndDate = s.data?.appliedScheme?.endDate
  //       ? moment(s.data.appliedScheme?.endDate).format("DD-MM-YYYY")
  //       : "";

  //     return {
  //       __savedIndex: idx,
  //       itemCode: s.itemCode,
  //       "Branch Code": s.branchCode ?? s.data?.branchCode ?? "",
  //       Stock: s.data?.["Str Stk"] || 0,
  //       "Old Scheme Type": s.data?.["Scheme Type"],
  //       "Old Scheme Group": s.data?.["Scheme Group"],
  //       "Scheme Type": s.data?.appliedScheme?.schemeType?.value || "",
  //       "Scheme Group": s.data?.appliedScheme?.schemeGroup?.value || "",
  //       "Scheme Start Date": formattedStartDate,
  //       "Scheme End Date": formattedEndDate,
  //       "Display Type":
  //         s.data?.appliedDisplay != null
  //           ? s.data?.appliedDisplay?.displayType?.value
  //           : "",
  //       // include savedAt so fallback deletion can use it
  //       savedAt: s.savedAt,
  //     };
  //   });
  // }, [savedSchemes]);

  // -------------------
  // delete handler must be defined BEFORE columnDefs
  // -------------------

  const rowData = useMemo(() => {
    return savedSchemes.map((s: any, idx: number) => {
      const appliedDisplay = s.data?.appliedDisplay;

      // Safely extract displayType.value as string, default to empty string
      const displayTypeValue =
        appliedDisplay?.displayType?.value != null
          ? String(appliedDisplay.displayType.value)
          : "";

      // Format dates
      const formattedStartDate = s.data?.appliedScheme?.startDate
        ? moment(s.data.appliedScheme.startDate).format("DD-MM-YYYY")
        : "";
      const formattedEndDate = s.data?.appliedScheme?.endDate
        ? moment(s.data.appliedScheme.endDate).format("DD-MM-YYYY")
        : "";

      return {
        __savedIndex: idx,
        itemCode: s.itemCode,
        "Branch Code": s.branchCode ?? s.data?.branchCode ?? "",
        Stock: s.data?.["Str Stk"] || 0,
        "Old Scheme Type": s.data?.["Scheme Type"] || s.data?.scheme_type || "",
        "Old Scheme Group":
          s.data?.["Scheme Group"] || s.data?.scheme_group || "",
        "Scheme Type": s.data?.appliedScheme?.schemeType?.label ?? "",
        "Scheme Group": s.data?.appliedScheme?.schemeGroup?.label ?? "",
        "Scheme Start Date": formattedStartDate,
        "Scheme End Date": formattedEndDate,
        "Display Type": displayTypeValue, // ← Fixed: always a string
        savedAt: s.savedAt,
      };
    });
  }, [savedSchemes]);

  const onDeleteRow = useCallback(
    (row: any) => {
      if (!row) return;

      const itemCode = row.itemCode;
      const branchCode = normalizeBranchFromRow(row); // undefined if empty

      // confirm message includes branch if present
      const confirmMsg = itemCode
        ? branchCode
          ? `Delete saved scheme for Item Code "${itemCode}" at Branch "${branchCode}"?`
          : `Delete saved scheme for Item Code "${itemCode}" (global)?`
        : `Delete this saved scheme?`;

      if (!window.confirm(confirmMsg)) return;

      // If itemCode exists
      if (itemCode) {
        if (branchCode) {
          // delete branch-specific entry (dispatch object with both)
          dispatch(
            removeSavedSchemeByItemCode({
              itemCode: String(itemCode),
              branchCode: String(branchCode),
            } as any)
          );
        } else {
          // delete global entry (dispatch string itemCode)
          dispatch(removeSavedSchemeByItemCode(String(itemCode)));
        }
        return;
      }

      // fallback: remove by savedAt (rebuild the list similar to previous logic)
      if (row.savedAt) {
        const remaining = (savedSchemes || []).filter(
          (s: any) => s.savedAt !== row.savedAt
        );

        dispatch(clearSavedSchemes());
        remaining.forEach((s: any) => {
          dispatch(saveScheme({ row: s.data, scheme: {} }));
        });
        return;
      }

      console.warn("Unable to delete row: no itemCode or savedAt found.");
    },
    [dispatch, savedSchemes, normalizeBranchFromRow]
  );

  // build columnDefs dynamically from the first row's keys (excluding internal keys)
  const columnDefs = useMemo(() => {
    if (!rowData || rowData.length === 0) {
      // minimal default columns with actions
      return [
        {
          headerName: "Actions",
          field: "actions",
          cellRenderer: (params: any) => {
            return (
              <div style={{ display: "flex", gap: 8 }}>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteRow(params.data);
                  }}
                  className="btn btn-sm btn-primary"
                  title="Delete"
                >
                  Delete
                </button>
              </div>
            );
          },
          pinned: "right",
          width: 120,
        },
      ];
    }

    // get all keys from first row
    const keys = Object.keys(rowData[0]).filter(
      (k) => !["__savedIndex"].includes(k)
    );

    const cols = keys
      .filter((k) => k !== "actions")
      .map((key) => {
        const headerName = toTitleCase(String(key).replace(/_/g, " "));
        const base: any = {
          headerName,
          field: key,
          sortable: true,
          filter: true,
          resizable: true,
        };
        if (key === "savedAt") base.width = 180;
        if (key === "itemCode") base.width = 160;
        return base;
      });

    // append actions column
    cols.push({
      headerName: "Actions",
      field: "actions",
      cellRenderer: (params: any) => {
        return (
          <div style={{ display: "flex", gap: 8 }}>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDeleteRow(params.data);
              }}
              className="btn btn-sm btn-danger"
              title="Delete"
            >
              Delete
            </button>
          </div>
        );
      },
      pinned: "right",
      width: 120,
    });

    return cols;
  }, [rowData, onDeleteRow]);

  const heading = toTitleCase(String(activeTab || "schemes"));

  return (
    <Wrapper
      header="Scheme And Display"
      subHeader="Applied Schemes & Display"
      ExportR={1}
      backButtonName="Back"
    >
      {loading ? (
        <CenteredLoader />
      ) : (
        <GridTable
          rowData={rowData}
          columnDefs={columnDefs}
          enableEditing={false}
          enableSelection={false}
          height={tableHeight}
          reportHeader={`Phase_3_${heading}_Summary`}
        />
      )}
    </Wrapper>
  );
};

export default SchemePage;
