// // src/pages/phase3/Phase3Page.tsx
// import React, { useEffect, useMemo, useCallback } from "react";
// import { useNavigate, useLocation } from "react-router-dom";
// import Wrapper from "../../common/uicomponent/wrapper";
// import GridTable from "../../common/component/GridTable";
// import CenteredLoader from "../../common/component/CenteredLoader";
// import { toNumber, toTitleCase } from "./helperfunc";
// import { useDispatch, useSelector } from "react-redux";
// import { RootState } from "../../redux/store";
// import {
//   setActiveTab,
//   setTableHeight,
//   saveScheme,
// } from "../../redux/phase3Slice";
// import { openModal, closeModal } from "../../redux/modalSlice";
// import ReusableModal from "../../common/component/ReusableModal";
// import { FormProvider, useForm } from "react-hook-form";
// import scheme, { display } from "../../core/json/scheme";
// import { renderField } from "../../common/utils/renderField";

// const Phase3Page: React.FC = () => {
//   const navigate = useNavigate();
//   const dispatch = useDispatch();
//   const location = useLocation();

//   // --- selectors from store (matching your earlier code) ---
//   const summaries = useSelector((s: RootState) => s.phase3.summaries);
//   const departmentSummaries = useSelector(
//     (s: RootState) => s.phase3.departmentSummaries
//   );
//   const savedSchemes = useSelector((s: RootState) => s.phase3.savedSchemes);
//   const itemsSummaries = useSelector((s: RootState) => s.phase3.itemSummaries);
//   const loading = useSelector((s: RootState) => s.phase3.loading);
//   const error = useSelector((s: RootState) => s.phase3.error);
//   const activeTab = useSelector((s: RootState) => s.phase3.activeTab);
//   const tableHeight = useSelector((s: RootState) => s.phase3.tableHeight);

//   // Redux modal state
//   const modalOpen = useSelector((s: RootState) => s.modal.isOpen);
//   const modalConfig = useSelector((s: RootState) => s.modal.config);
//   console.log("savedSchemes", savedSchemes);
//   // react-hook-form instance
//   const form = useForm<any>({
//     mode: "onBlur",
//     defaultValues: {
//       startDate: null,
//       endDate: null,
//       schemeType: null,
//       schemeGroup: null,
//       displayType: null,
//     },
//   });

//   const { enable } = useMemo(() => {
//     const state = (location as any)?.state ?? {};
//     return {
//       enable: state.enable ?? 0,
//       bucket: state.bucket ?? null,
//     };
//   }, [location]);

//   const selectOptions = useMemo(
//     () => ({
//       schemeType: [{ value: 1, label: "scheme1" }],
//       schemeGroup: [{ value: 1, label: "schemeGrp1" }],
//       displayType: [{ value: 1, label: "display1" }],
//     }),
//     []
//   );

//   const renderFieldWrapper = useCallback(
//     (field: any, key: string) =>
//       renderField({
//         field,
//         form,
//         options: field.props?.name
//           ? selectOptions[field.props.name as keyof typeof selectOptions] || []
//           : [],
//         key,
//       }),
//     [form, selectOptions]
//   );

//   // const handleFormSave = useCallback(async (data: any) => {
//   //   // Not used directly — we use form.handleSubmit inline in modal Save button.
//   //   console.log("handleFormSave", data);
//   // }, []);

//   // -------------------------------------------------
//   //  TRANSFORMED DATA (same as your original)
//   // -------------------------------------------------
//   const departmentData = useMemo(
//     () =>
//       departmentSummaries.map((d: any) => ({
//         Department: d?.department,
//         "Str Stk": Math.round(d?.total_site_quantity || 0),
//         "Stk Val": Math.round(d?.total_str_stk_sp_value || 0),
//         "Sale Qty": Math.round(d?.total_sale_quantity || 0),
//         "Sale Val": Math.round(d?.total_sale_value || 0),
//         "Stk Qty Contri": `${Number(d?.stock_qty_contri).toFixed(2)}%`,
//         "Stk Val Contri": `${Number(d?.stock_val_contri).toFixed(2)}%`,
//       })),
//     [departmentSummaries]
//   );

//   const branchData = useMemo(
//     () =>
//       summaries.map((d: any) => ({
//         "Branch Code": d?.branch_code,
//         "Branch Name": d?.branch_name,
//         State: d?.state,
//         "Str Stk": Math.round(d?.total_site_quantity || 0),
//         "Stk Val": Math.round(d?.total_str_stk_sp_value || 0),
//         "Sale Qty": Math.round(d?.total_sale_quantity || 0),
//         "Sale Val": Math.round(d?.total_sale_value || 0),
//         "Stk Qty Contri": `${Number(d?.stock_qty_contri).toFixed(2)}%`,
//         "Stk Val Contri": `${Number(d?.stock_val_contri).toFixed(2)}%`,
//       })),
//     [summaries]
//   );

//   const itemsData = useMemo(
//     () =>
//       itemsSummaries.map((d: any) => ({
//         "Item Code": d?.item_code,
//         "Item Name": d?.item_name,
//         Department: d?.department,
//         Category: d?.category,
//         "Sub Category": d?.subcategory,
//         "Item Status": d?.active_inactive,
//         Desc: d?.item_desc,
//         "Scheme Type": d?.scheme_type,
//         "Scheme Group": d?.scheme_group,
//         "Str Stk": Math.round(d?.total_site_quantity || 0),
//         "Sale Qty": Math.round(d?.total_sale_quantity || 0),
//         "Sale Val": Math.round(d?.total_sale_value || 0),
//         "Stk Val": Math.round(d?.total_str_stk_sp_value || 0),
//         "Stk Qty Contri": `${Number(d?.stock_qty_contri).toFixed(2)}%`,
//         "Stk Val Contri": `${Number(d?.stock_val_contri).toFixed(2)}%`,
//       })),
//     [itemsSummaries]
//   );

//   // -------------------------------------------------
//   //  COLUMN DEFINITIONS (makeCols)
//   // -------------------------------------------------
//   const makeCols = useCallback((data: any[]) => {
//     if (!data.length) return [];
//     const first = data[0];
//     const allKeys = Object.keys(first);
//     const totalColumns = allKeys.length;
//     const defaultFlex = totalColumns <= 7 ? 1 : 0;

//     return allKeys.map((k) => {
//       const isContriColumn = k === "Stk Qty Contri" || k === "Stk Val Contri";

//       return {
//         field: k,
//         headerName: toTitleCase(k),
//         sortable: true,
//         resizable: true,
//         filter:
//           typeof first[k] === "string"
//             ? "agTextColumnFilter"
//             : "agNumberColumnFilter",
//         pinned: isContriColumn ? "right" : null,
//         width: isContriColumn ? 150 : undefined,
//         lockPosition: isContriColumn,
//         cellStyle: isContriColumn ? { textAlign: "right" } : undefined,
//         flex: isContriColumn ? 0 : defaultFlex,
//         valueFormatter: isContriColumn
//           ? (params: any) => {
//               const val = params.value;
//               if (val == null) return "";
//               const num = parseFloat(val.replace("%", "").trim());
//               return isNaN(num) ? val : `${num.toFixed(2)}%`;
//             }
//           : undefined,
//         getQuickFilterText: isContriColumn
//           ? (params: any) => {
//               const val = params.value;
//               return val
//                 ? parseFloat(val.replace("%", "").trim()).toString()
//                 : "";
//             }
//           : undefined,
//         comparator: isContriColumn
//           ? (a: any, b: any) => {
//               const numA = parseFloat((a || "").replace("%", "").trim()) || 0;
//               const numB = parseFloat((b || "").replace("%", "").trim()) || 0;
//               return numA - numB;
//             }
//           : undefined,
//       };
//     });
//   }, []);

//   const deptColumnDefs = useMemo(
//     () => makeCols(departmentData),
//     [departmentData, makeCols]
//   );
//   const branchColumnDefs = useMemo(
//     () => makeCols(branchData),
//     [branchData, makeCols]
//   );
//   const itemColumnDefs = useMemo(
//     () => makeCols(itemsData),
//     [itemsData, makeCols]
//   );

//   const currentData: any =
//     activeTab === "branch"
//       ? branchData
//       : activeTab === "department"
//       ? departmentData
//       : itemsData;
//   const currentColumnDefs: any =
//     activeTab === "branch"
//       ? branchColumnDefs
//       : activeTab === "department"
//       ? deptColumnDefs
//       : itemColumnDefs;

//   // Append Scheme and Display columns for item view
//   const displayedColumnDefs = useMemo(() => {
//     const cols = Array.isArray(currentColumnDefs) ? [...currentColumnDefs] : [];

//     if (activeTab === "item") {
//       cols.push(
//         {
//           field: "Scheme",
//           headerName: "Scheme",
//           sortable: false,
//           resizable: true,
//           pinned: "right",
//           filter: false,
//           lockPosition: false,
//           cellRenderer: (params: any) => {
//             const onClick = (ev: any) => {
//               ev.stopPropagation();
//               form.reset({
//                 startDate: null,
//                 endDate: null,
//                 schemeType: null,
//                 schemeGroup: null,
//                 displayType: null,
//               });
//               dispatch(
//                 openModal({
//                   title: "Apply New Scheme",
//                   size: "lg",
//                   content: (
//                     <FormProvider {...form}>
//                       <form onSubmit={form.handleSubmit(() => {})}>
//                         <div className="mb-4 p-3 bg-light rounded border">
//                           <div className="d-flex align-items-center mb-2">
//                             <div className="me-3 p-2 bg-white rounded border flex-grow-1">
//                               <small className="text-muted d-block">
//                                 Item Code
//                               </small>
//                               <strong className="text-primary">
//                                 {params.data["Item Code"] || "N/A"}
//                               </strong>
//                             </div>
//                             <div className="p-2 bg-white rounded border flex-grow-2">
//                               <small className="text-muted d-block">
//                                 Item Name
//                               </small>
//                               <strong className="text-primary">
//                                 {params.data["Item Name"] || "N/A"}
//                               </strong>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="row">
//                           {Object.entries(scheme.properties).map(
//                             ([key, field]) => (
//                               <div key={key} className="col-lg-6 col-md-6 mb-3">
//                                 {renderFieldWrapper(field as any, key)}
//                               </div>
//                             )
//                           )}
//                         </div>
//                       </form>
//                     </FormProvider>
//                   ),
//                   footerButtons: [
//                     {
//                       label: "Close",
//                       variant: "secondary",
//                       onClick: () => dispatch(closeModal()),
//                     },
//                     {
//                       label: "Save",
//                       variant: "primary",
//                       onClick: () =>
//                         // Run validation and on success dispatch save action
//                         form.handleSubmit((data: any) => {
//                           // Save both row and scheme data to redux
//                           dispatch(
//                             saveScheme({
//                               row: params.data,
//                               scheme: data,
//                             })
//                           );
//                           // Close modal
//                           dispatch(closeModal());
//                         })(),
//                     },
//                   ],
//                 })
//               );
//             };

//             return (
//               <button
//                 className="btn btn-sm btn-outline-primary"
//                 onClick={onClick}
//                 type="button"
//               >
//                 Apply
//               </button>
//             );
//           },
//           width: 90,
//         },
//         {
//           field: "Display",
//           headerName: "Display",
//           sortable: false,
//           resizable: true,
//           pinned: "right",
//           filter: false,
//           lockPosition: false,
//           cellRenderer: (params: any) => {
//             const onClick = (ev: any) => {
//               ev.stopPropagation();
//               form.reset({
//                 startDate: null,
//                 endDate: null,
//                 schemeType: null,
//                 schemeGroup: null,
//                 displayType: null,
//               });
//               dispatch(
//                 openModal({
//                   title: "Display",
//                   size: "lg",
//                   content: (
//                     // <pre
//                     //   style={{
//                     //     whiteSpace: "pre-wrap",
//                     //     wordBreak: "break-word",
//                     //   }}
//                     // >
//                     //   {JSON.stringify(params.data, null, 2)}
//                     // </pre>
//                     <FormProvider {...form}>
//                       <form onSubmit={form.handleSubmit(() => {})}>
//                         <div className="mb-4 p-3 bg-light rounded border">
//                           <div className="d-flex align-items-center mb-2">
//                             <div className="me-3 p-2 bg-white rounded border flex-grow-1">
//                               <small className="text-muted d-block">
//                                 Item Code
//                               </small>
//                               <strong className="text-primary">
//                                 {params.data["Item Code"] || "N/A"}
//                               </strong>
//                             </div>
//                             <div className="p-2 bg-white rounded border flex-grow-2">
//                               <small className="text-muted d-block">
//                                 Item Name
//                               </small>
//                               <strong className="text-primary">
//                                 {params.data["Item Name"] || "N/A"}
//                               </strong>
//                             </div>
//                           </div>
//                         </div>

//                         <div className="row">
//                           {Object.entries(display.properties).map(
//                             ([key, field]) => (
//                               <div
//                                 key={key}
//                                 className="col-lg-12 col-md-12 mb-3"
//                               >
//                                 {renderFieldWrapper(field as any, key)}
//                               </div>
//                             )
//                           )}
//                         </div>
//                       </form>
//                     </FormProvider>
//                   ),
//                   footerButtons: [
//                     {
//                       label: "Close",
//                       variant: "secondary",
//                       onClick: () => dispatch(closeModal()),
//                     },
//                     {
//                       label: "Save",
//                       variant: "primary",
//                       onClick: () =>
//                         // Run validation and on success dispatch save action
//                         form.handleSubmit((data: any) => {
//                           // Save both row and scheme data to redux
//                           dispatch(
//                             saveScheme({
//                               row: params.data,
//                               scheme: data,
//                             })
//                           );
//                           // Close modal
//                           dispatch(closeModal());
//                         })(),
//                     },
//                   ],
//                 })
//               );
//             };
//             return (
//               <button
//                 className="btn btn-sm btn-outline-secondary"
//                 onClick={onClick}
//                 type="button"
//               >
//                 Apply
//               </button>
//             );
//           },
//           width: 90,
//         }
//       );
//     }

//     return cols;
//   }, [currentColumnDefs, activeTab, dispatch, form]);

//   // -------------------------------------------------
//   //  RESPONSIVE HEIGHT
//   // -------------------------------------------------
//   useEffect(() => {
//     const calculateTableHeight = () => {
//       const windowHeight = window.innerHeight;
//       const windowWidth = window.innerWidth;
//       const headerHeight = 150;
//       const footerHeight = 10;
//       const bottomSpace = 50;
//       const minHeight = 400;
//       const tabletMinWidth = 768;
//       const tabletMaxWidth = 1024;
//       let calculatedHeight: number;

//       if (windowWidth >= 1200) {
//         calculatedHeight =
//           windowHeight - headerHeight - footerHeight - bottomSpace;
//       } else if (
//         windowWidth >= tabletMinWidth &&
//         windowWidth <= tabletMaxWidth
//       ) {
//         const tabletAdjustment = windowWidth < 900 ? 150 : 100;
//         calculatedHeight =
//           windowHeight - headerHeight - footerHeight - tabletAdjustment;
//       } else {
//         calculatedHeight = windowHeight - headerHeight - footerHeight - 100;
//       }

//       dispatch(setTableHeight(`${Math.max(calculatedHeight, minHeight)}px`));
//     };

//     calculateTableHeight();
//     window.addEventListener("resize", calculateTableHeight);
//     window.addEventListener("orientationchange", calculateTableHeight);
//     return () => {
//       window.removeEventListener("resize", calculateTableHeight);
//       window.removeEventListener("orientationchange", calculateTableHeight);
//     };
//   }, [dispatch]);

//   // -------------------------------------------------
//   //  DRILL-DOWN
//   // -------------------------------------------------
//   const handleDrillDown = (e: any) => {
//     const domEvent = e?.event;
//     if (domEvent && domEvent.target) {
//       const targetEl = domEvent.target as HTMLElement;
//       if (targetEl.closest("button") || targetEl.closest("a")) {
//         return;
//       }
//       if (targetEl.closest(".no-drill")) {
//         return;
//       }
//     }

//     if (!e?.data) return;

//     const dept = e.data.Department ?? "";
//     const branch = e.data["Branch Code"] ?? "";
//     const item = e.data["Item Code"] ?? "";

//     if (activeTab === "department" && dept) {
//       navigate("/dynamictable/1", { state: { department: dept } });
//     } else if (activeTab === "branch" && branch) {
//       navigate("/dynamictable/1", { state: { branchCode: branch } });
//     } else if (activeTab === "item" && item) {
//       navigate("/dynamictable/2", { state: { itemCode: item } });
//     }
//   };

//   // -------------------------------------------------
//   //  TOTAL SUMMARY
//   // -------------------------------------------------
//   const totalSummary = useMemo(() => {
//     if (!currentData.length) return {};

//     const keys = Object.keys(currentData[0]);
//     const totals: Record<string, number> = {};

//     keys.forEach((k) => {
//       if (
//         !k.includes("Contri") &&
//         !(activeTab === "department" && k === "Department") &&
//         !(
//           activeTab === "branch" &&
//           (k === "Branch Code" || k === "Branch Name" || k === "State")
//         ) &&
//         !(
//           activeTab === "item" &&
//           (k === "Department" ||
//             k === "Item Code" ||
//             k === "Item Name" ||
//             k === "Category" ||
//             k === "Sub Category" ||
//             k === "Item Status" ||
//             k === "Desc")
//         )
//       ) {
//         totals[k] = 0;
//       }
//     });

//     currentData.forEach((row: any) => {
//       keys.forEach((k) => {
//         if (k.includes("Contri")) return;
//         if (activeTab === "department" && k === "Department") return;
//         if (
//           activeTab === "branch" &&
//           (k === "Branch Code" || k === "Branch Name" || k === "State")
//         )
//           return;
//         if (
//           activeTab === "item" &&
//           (k === "Department" ||
//             k === "Item Code" ||
//             k === "Item Name" ||
//             k === "Category" ||
//             k === "Sub Category" ||
//             k === "Item Status" ||
//             k === "Desc")
//         )
//           return;

//         const n = toNumber(row[k]);
//         if (!Number.isNaN(n)) totals[k] += n;
//       });
//     });

//     Object.keys(totals).forEach((k) => {
//       totals[k] = Math.round(totals[k]);
//     });

//     return totals;
//   }, [currentData, activeTab]);

//   // -------------------------------------------------
//   //  RENDER
//   // -------------------------------------------------
//   return (
//     <Wrapper header="Summaries" subHeader="Report" ExportR={1}>
//       <div className="mb-3">
//         {loading && <CenteredLoader />}

//         {/* Tabs */}
//         <ul className="nav nav-tabs mb-1 pb-1">
//           {(["department", "branch", "item"] as const).map((tab) => {
//             const labels = {
//               department: "Department-wise summary",
//               branch: "Branch-wise summary",
//               item: "Item-wise summary",
//             };
//             return (
//               <li className="nav-item" key={tab}>
//                 <button
//                   className={`nav-link px-4 py-2 rounded-top ${
//                     activeTab === tab
//                       ? "active fw-semibold text-primary border-primary"
//                       : "text-muted"
//                   }`}
//                   onClick={() => dispatch(setActiveTab(tab))}
//                   style={{
//                     border: "none",
//                     backgroundColor: "transparent",
//                     borderBottom:
//                       activeTab === tab
//                         ? "2px solid #0d6efd"
//                         : "2px solid transparent",
//                   }}
//                 >
//                   {labels[tab]}
//                 </button>
//               </li>
//             );
//           })}
//         </ul>

//         {/* Active Count + Total Summary */}
//         {!loading && !error && currentData.length > 0 && (
//           <div className="d-flex flex-wrap gap-2 mb-1 align-items-center">
//             <span
//               className="badge bg-primary text-white px-3 py-2 rounded-2 fw-medium"
//               style={{ fontSize: "0.92rem" }}
//             >
//               {activeTab === "department"
//                 ? `${departmentSummaries.length} Department${
//                     departmentSummaries.length !== 1 ? "s" : ""
//                   }`
//                 : activeTab === "branch"
//                 ? `${summaries.length} Branch${
//                     summaries.length !== 1 ? "es" : ""
//                   }`
//                 : `${itemsSummaries.length} Item${
//                     itemsSummaries.length !== 1 ? "s" : ""
//                   }`}
//             </span>

//             {Object.entries(totalSummary).map(([key, value]) => {
//               if (key.includes("Contri")) return null;
//               return (
//                 <span
//                   key={key}
//                   className="badge bg-light text-dark border px-3 py-2 fw-medium"
//                   style={{ fontSize: "0.875rem" }}
//                   title={toTitleCase(key)}
//                 >
//                   <strong>{toTitleCase(key)}:</strong> {value.toLocaleString()}
//                 </span>
//               );
//             })}
//           </div>
//         )}

//         {/* Loading / Error */}
//         {(loading || error) && (
//           <div className="mb-3">
//             <span
//               className={`badge px-3 py-2 rounded-2 ${
//                 loading ? "bg-info text-white" : "bg-danger text-white"
//               }`}
//               style={{ fontSize: "0.92rem", fontWeight: 500 }}
//             >
//               {loading ? "Loading data..." : "Failed to load data"}
//             </span>
//           </div>
//         )}

//         {/* Empty */}
//         {!loading && !error && currentData.length === 0 && (
//           <div className="text-center py-4 text-muted">
//             No data available for the selected view.
//           </div>
//         )}

//         {/* Table */}
//         {!loading && !error && currentData.length > 0 && (
//           <div className="border rounded-2 overflow-hidden shadow-sm">
//             <GridTable
//               rowData={currentData}
//               columnDefs={displayedColumnDefs}
//               enableEditing={false}
//               enableSelection={false}
//               height={tableHeight}
//               onRowClick={enable != 1 && (handleDrillDown as any)}
//               reportHeader={`Phase_3_${activeTab}_Summary`}
//             />
//           </div>
//         )}

//         {/* Reusable Modal */}
//         <ReusableModal
//           isOpen={modalOpen}
//           onClose={() => dispatch(closeModal())}
//           title={modalConfig?.title}
//           size={modalConfig?.size}
//           centered={modalConfig?.centered}
//           closeButton={modalConfig?.closeButton}
//           footerButtons={modalConfig?.footerButtons}
//           backdrop={modalConfig?.backdrop}
//         >
//           {modalConfig?.content}
//         </ReusableModal>
//       </div>
//     </Wrapper>
//   );
// };

// export default Phase3Page;

// src/pages/phase3/Phase3Page.tsx
import React, { useEffect, useMemo, useCallback, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Wrapper from "../../common/uicomponent/wrapper";
import GridTable from "../../common/component/GridTable";
import CenteredLoader from "../../common/component/CenteredLoader";
import { toNumber, toTitleCase } from "./helperfunc";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../redux/store";
import {
  setActiveTab,
  setTableHeight,
  saveScheme,
  removeSavedSchemeByItemCode,
} from "../../redux/phase3Slice";
import {
  fetchSchemeTypes,
  fetchSchemeGroups,
  clearSchemeGroups,
} from "../../redux/schemeOptionsSlice";
import { FormProvider, useForm } from "react-hook-form";
import scheme, { display } from "../../core/json/scheme";
import { renderField } from "../../common/utils/renderField";
import useFetch from "../../hooks/useFetch";

// Local Modal Component (unchanged)
// const LocalModal: React.FC<{
//   isOpen: boolean;
//   onClose: () => void;
//   title: string;
//   size?: "sm" | "md" | "lg" | "xl";
//   footerButtons?: Array<{
//     label: string;
//     variant: string;
//     onClick: () => void;
//   }>;
//   children: React.ReactNode;
// }> = ({ isOpen, onClose, title, size = "md", footerButtons, children }) => {
//   if (!isOpen) return null;

//   const sizeClasses = {
//     sm: "modal-sm",
//     md: "",
//     lg: "modal-lg",
//     xl: "modal-xl",
//   };

//   return (
//     <div
//       className="modal fade show d-block"
//       style={{ backgroundColor: "rgba(0,0,0,0.5)" }}
//       tabIndex={-1}
//     >
//       <div
//         className={`modal-dialog ${sizeClasses[size]} modal-dialog-centered`}
//       >
//         <div className="modal-content">
//           <div className="modal-header">
//             <h5 className="modal-title">{title}</h5>
//             <button
//               type="button"
//               className="btn-close"
//               onClick={onClose}
//               aria-label="Close"
//             ></button>
//           </div>
//           <div className="modal-body">{children}</div>
//           {footerButtons && footerButtons.length > 0 && (
//             <div className="modal-footer">
//               {footerButtons.map((btn, idx) => (
//                 <button
//                   key={idx}
//                   type="button"
//                   className={`btn btn-${btn.variant}`}
//                   onClick={btn.onClick}
//                 >
//                   {btn.label}
//                 </button>
//               ))}
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// LocalModal: support content as ReactNode OR () => ReactNode
const LocalModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  title: string;
  size?: "sm" | "md" | "lg" | "xl";
  footerButtons?: Array<{
    label: string;
    variant: string;
    onClick: () => void;
  }>;
  // allow content to be a render function so children are created at render-time
  children?: React.ReactNode | (() => React.ReactNode);
}> = ({ isOpen, onClose, title, size = "md", footerButtons, children }) => {
  if (!isOpen) return null;

  const sizeClasses = {
    sm: "modal-sm",
    md: "",
    lg: "modal-lg",
    xl: "modal-xl",
  };

  // if children is a function, call it to get the render-time JSX
  const renderedChildren =
    typeof children === "function"
      ? (children as () => React.ReactNode)()
      : children;

  return (
    <div
      className="modal fade show d-block"
      style={{ backgroundColor: "rgba(0,0,0,0.5)" }}
      tabIndex={-1}
    >
      <div
        className={`modal-dialog ${sizeClasses[size]} modal-dialog-centered`}
      >
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">{title}</h5>
            <button
              type="button"
              className="btn-close"
              onClick={onClose}
              aria-label="Close"
            />
          </div>
          <div className="modal-body">{renderedChildren}</div>
          {footerButtons && footerButtons.length > 0 && (
            <div className="modal-footer">
              {footerButtons.map((btn, idx) => (
                <button
                  key={idx}
                  type="button"
                  className={`btn btn-${btn.variant}`}
                  onClick={btn.onClick}
                >
                  {btn.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const Phase3Page: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const location = useLocation();
  const callFetch = useFetch();

  // --- Phase 3 Selectors ---
  const summaries = useSelector((s: RootState) => s.phase3.summaries);
  const departmentSummaries = useSelector(
    (s: RootState) => s.phase3.departmentSummaries
  );
  const savedSchemes = useSelector((s: RootState) => s.phase3.savedSchemes);
  const itemsSummaries = useSelector((s: RootState) => s.phase3.itemSummaries);
  const loading = useSelector((s: RootState) => s.phase3.loading);
  const error = useSelector((s: RootState) => s.phase3.error);
  const activeTab = useSelector((s: RootState) => s.phase3.activeTab);
  const tableHeight = useSelector((s: RootState) => s.phase3.tableHeight);

  // --- Scheme Options Selectors ---
  const {
    types: rawSchemeTypes,
    groups: rawSchemeGroups,
    loadingTypes,
    loadingGroups,
    error: schemeOptionsError,
  } = useSelector((s: RootState) => s.schemeOptions);

  // --- Local Modal State (unchanged shape) ---
  const [modalConfig, setModalConfig] = React.useState<{
    isOpen: boolean;
    title: string;
    size: "sm" | "md" | "lg" | "xl";
    content: React.ReactNode;
    footerButtons?: Array<{
      label: string;
      variant: string;
      onClick: () => void;
    }>;
  }>({
    isOpen: false,
    title: "",
    size: "lg",
    content: null,
  });

  // --- Form ---
  const form = useForm<any>({
    mode: "onBlur",
    defaultValues: {
      startDate: null,
      endDate: null,
      schemeType: null,
      schemeGroup: null,
      displayType: null,
    },
  });

  const defaultFormValues = {
    startDate: null,
    endDate: null,
    schemeType: null,
    schemeGroup: null,
    displayType: null,
  };

  const selectedSchemeType = form.watch("schemeType");

  const { enable } = useMemo(() => {
    const state = (location as any)?.state ?? {};
    return {
      enable: state.enable ?? 0,
      bucket: state.bucket ?? null,
    };
  }, [location]);

  // --- fetch scheme types once ---
  useEffect(() => {
    dispatch(fetchSchemeTypes() as any);
  }, [dispatch]);

  // --- when scheme type changes fetch groups (or clear) ---
  useEffect(() => {
    const id = (selectedSchemeType &&
      (selectedSchemeType.value ?? selectedSchemeType)) as
      | number
      | string
      | undefined;

    if (id) {
      // clear any previously selected group immediately to avoid showing a stale object
      try {
        form.setValue("schemeGroup", null);
      } catch {}
      dispatch(fetchSchemeGroups(Number(id)) as any);
    } else {
      dispatch(clearSchemeGroups());
      try {
        form.setValue("schemeGroup", null);
      } catch {
        /* ignore */
      }
    }
  }, [selectedSchemeType, dispatch, form]);

  // --- normalize raw scheme types/groups into {value,label} and keep raw ref ---
  const schemeTypes = useMemo(() => {
    if (!Array.isArray(rawSchemeTypes)) return [];
    return rawSchemeTypes.map((t: any) => {
      const value =
        t?.value ?? t?.id ?? t?.type_id ?? t?.code ?? t?.key ?? t?.name ?? "";
      const label = t?.label ?? t?.name ?? t?.type_name ?? String(value);
      return { value: String(value), label: String(label), __raw: t };
    });
  }, [rawSchemeTypes]);

  const schemeGroups = useMemo(() => {
    if (!Array.isArray(rawSchemeGroups)) return [];
    return rawSchemeGroups.map((g: any) => {
      const value =
        g?.value ??
        g?.id ??
        g?.group_id ??
        g?.scheme_group_id ??
        g?.code ??
        g?.key ??
        g?.name ??
        "";
      const label =
        g?.label ?? g?.name ?? g?.group_name ?? g?.title ?? String(value);
      return { value: String(value), label: String(label), __raw: g };
    });
  }, [rawSchemeGroups]);

  // key to force remount of schemeGroup select if required
  const [schemeGroupKey, setSchemeGroupKey] = useState(0);

  // When normalized groups change, bump key and sync form value -> option object or clear
  useEffect(() => {
    setSchemeGroupKey((k) => k + 1);

    try {
      const current = form.getValues("schemeGroup");
      if (!current) {
        // nothing selected — done
        return;
      }
      const currentVal =
        typeof current === "object" ? current.value ?? current : current;
      if (
        currentVal === null ||
        currentVal === undefined ||
        String(currentVal) === ""
      ) {
        form.setValue("schemeGroup", null);
        return;
      }
      const matched = schemeGroups.find(
        (o) => String(o.value) === String(currentVal)
      );
      if (matched) {
        // set the exact instance from schemeGroups to preserve identity
        form.setValue("schemeGroup", matched);
      } else {
        // no match — clear
        form.setValue("schemeGroup", null);
      }
    } catch {
      // ignore errors here
    }
    // only depend on raw groups so effect runs when source changes
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rawSchemeGroups]);

  // central openLocalModal: now accepts optional preset and resets form appropriately
  const openLocalModal = (
    config: Omit<typeof modalConfig, "isOpen">,
    preset?: any
  ) => {
    // normalize preset so select fields get option objects (when possible)
    let normalizedPreset = preset ? { ...preset } : undefined;

    try {
      // always reset to defaults first to avoid stale values
      form.reset(defaultFormValues);

      if (normalizedPreset) {
        // convert schemeType to option object if possible
        const incomingTypeVal =
          normalizedPreset.schemeType?.value ?? normalizedPreset.schemeType;
        if (incomingTypeVal !== undefined && incomingTypeVal !== null) {
          const matchType = schemeTypes.find(
            (t) => String(t.value) === String(incomingTypeVal)
          );
          if (matchType) {
            normalizedPreset.schemeType = matchType;
          }
        }

        // For schemeGroup, prefer setting to null here — groups might not be loaded yet.
        // We'll let the effect that runs when rawSchemeGroups changes try to restore it.
        if (normalizedPreset.schemeGroup) {
          const incomingGroupVal =
            normalizedPreset.schemeGroup?.value ?? normalizedPreset.schemeGroup;
          const matchGroup = schemeGroups.find(
            (g) => String(g.value) === String(incomingGroupVal)
          );
          if (matchGroup) {
            normalizedPreset.schemeGroup = matchGroup;
          } else {
            // clear until groups load
            normalizedPreset.schemeGroup = null;
          }
        }

        // Now set the preset into the form
        form.reset(normalizedPreset);
      } else {
        // ensure schemeGroup cleared when no preset
        form.setValue("schemeGroup", null);
      }
    } catch (err) {
      // ignore if form not ready
    }

    // bump schemeGroupKey to force remount of select
    setSchemeGroupKey((k) => k + 1);

    setModalConfig({ ...config, isOpen: true });
  };

  // close and clear form to avoid leaking values
  const closeLocalModal = () => {
    setModalConfig((prev) => ({ ...prev, isOpen: false }));
    try {
      // reset to defaults on close
      form.reset(defaultFormValues);
    } catch {
      /* ignore */
    }
    setTimeout(() => {
      setModalConfig({ isOpen: false, title: "", size: "lg", content: null });
    }, 300);
  };

  // selectOptions object for renderField
  const selectOptions = useMemo(
    () => ({
      schemeType: schemeTypes,
      schemeGroup: schemeGroups,
      displayType: [
        { value: "Send Shelf Picture", label: "Send Shelf Picture" },
      ],
    }),
    [schemeTypes, schemeGroups, selectedSchemeType]
  );

  const renderFieldWrapper = useCallback(
    (field: any, key: string) => {
      const name = (field?.props?.name ?? "") as keyof typeof selectOptions;
      const options = selectOptions[name] ?? [];
      console.log("Options", name);
      if (
        (name === "schemeType" && loadingTypes) ||
        (name === "schemeGroup" && loadingGroups)
      ) {
        return (
          <div key={key} className="p-2">
            <div
              className="spinner-border spinner-border-sm text-primary"
              role="status"
            >
              <span className="visually-hidden">Loading…</span>
            </div>
          </div>
        );
      }

      const fieldKey =
        name === "schemeGroup" ? `${key}-${schemeGroupKey}` : key;

      return renderField({
        field,
        form,
        options,
        key: fieldKey,
      });
    },
    [
      form,
      selectOptions,
      loadingTypes,
      loadingGroups,
      schemeGroupKey,
      selectedSchemeType,
    ]
  );

  // --------------------------
  // Helpers to normalize codes
  // --------------------------
  const getItemCodeFromRow = useCallback((row: any): string | undefined => {
    const raw =
      row?.["Item Code"] ??
      row?.itemCode ??
      row?.ItemCode ??
      row?.item_code ??
      row?.Item_Code ??
      row?.itemcode ??
      undefined;
    if (raw === undefined || raw === null) return undefined;
    const trimmed = String(raw).trim();
    return trimmed === "" ? undefined : trimmed;
  }, []);

  const getBranchCodeFromRow = useCallback((row: any): string | undefined => {
    const raw =
      row?.branchCode ??
      row?.Branch_Code ??
      row?.BranchCode ??
      row?.branch_code ??
      row?.branch ??
      row?.Branch ??
      undefined;
    if (raw === undefined || raw === null) return undefined;
    const trimmed = String(raw).trim();
    return trimmed === "" ? undefined : trimmed;
  }, []);

  const findSavedEntryForRow = useCallback(
    (row: any) => {
      const itemCode = getItemCodeFromRow(row);
      const branchCode = getBranchCodeFromRow(row);
      if (itemCode) {
        if (branchCode) {
          return savedSchemes.find(
            (s: any) =>
              String(s.itemCode ?? "")
                .trim()
                .toLowerCase() === String(itemCode).trim().toLowerCase() &&
              String(s.branchCode ?? "")
                .trim()
                .toLowerCase() === String(branchCode).trim().toLowerCase()
          );
        }
        const global = savedSchemes.find(
          (s: any) =>
            String(s.itemCode ?? "")
              .trim()
              .toLowerCase() === String(itemCode).trim().toLowerCase() &&
            (s.branchCode === undefined || s.branchCode === null)
        );
        return global;
      }
      try {
        const rowJson = JSON.stringify(row || {});
        return savedSchemes.find(
          (s: any) => JSON.stringify(s.data) === rowJson
        );
      } catch {
        return undefined;
      }
    },
    [savedSchemes, getItemCodeFromRow, getBranchCodeFromRow]
  );

  // --------------------------
  // Transform data & columns
  // --------------------------
  const departmentData = useMemo(
    () =>
      departmentSummaries.map((d: any) => ({
        Department: d?.department,
        "Str Stk": Math.round(d?.total_site_quantity || 0),
        "Stk Val": Math.round(d?.total_str_stk_sp_value || 0),
        "Sale Qty": Math.round(d?.total_sale_quantity || 0),
        "Sale Val": Math.round(d?.total_sale_value || 0),
        "Stk Qty Contri": `${Number(d?.stock_qty_contri).toFixed(2)}%`,
        "Stk Val Contri": `${Number(d?.stock_val_contri).toFixed(2)}%`,
      })),
    [departmentSummaries]
  );

  const branchData = useMemo(
    () =>
      summaries.map((d: any) => ({
        "Branch Code": d?.branch_code,
        "Branch Name": d?.branch_name,
        State: d?.state,
        "Str Stk": Math.round(d?.total_site_quantity || 0),
        "Stk Val": Math.round(d?.total_str_stk_sp_value || 0),
        "Sale Qty": Math.round(d?.total_sale_quantity || 0),
        "Sale Val": Math.round(d?.total_sale_value || 0),
        "Stk Qty Contri": `${Number(d?.stock_qty_contri).toFixed(2)}%`,
        "Stk Val Contri": `${Number(d?.stock_val_contri).toFixed(2)}%`,
      })),
    [summaries]
  );

  const itemsData = useMemo(
    () =>
      itemsSummaries.map((d: any) => ({
        "Item Code": d?.item_code,
        "Item Name": d?.item_name,
        Department: d?.department,
        Category: d?.category,
        "Sub Category": d?.subcategory,
        "Item Status": d?.active_inactive,
        Desc: d?.item_desc,
        "Scheme Type": d?.scheme_type,
        "Scheme Group": d?.scheme_group,
        "Str Stk": Math.round(d?.total_site_quantity || 0),
        "Sale Qty": Math.round(d?.total_sale_quantity || 0),
        "Sale Val": Math.round(d?.total_sale_value || 0),
        "Stk Val": Math.round(d?.total_str_stk_sp_value || 0),
        "Stk Qty Contri": `${Number(d?.stock_qty_contri).toFixed(2)}%`,
        "Stk Val Contri": `${Number(d?.stock_val_contri).toFixed(2)}%`,
      })),
    [itemsSummaries]
  );

  const makeCols = useCallback((data: any[]) => {
    if (!data.length) return [];
    const first = data[0];
    const allKeys = Object.keys(first);
    const totalColumns = allKeys.length;
    const defaultFlex = totalColumns <= 7 ? 1 : 0;

    return allKeys.map((k) => {
      const isContriColumn = k === "Stk Qty Contri" || k === "Stk Val Contri";

      return {
        field: k,
        headerName: toTitleCase(k),
        sortable: true,
        resizable: true,
        filter:
          typeof first[k] === "string"
            ? "agTextColumnFilter"
            : "agNumberColumnFilter",
        pinned: isContriColumn ? "right" : null,
        width: isContriColumn ? 150 : undefined,
        lockPosition: isContriColumn,
        cellStyle: isContriColumn ? { textAlign: "right" } : undefined,
        flex: isContriColumn ? 0 : defaultFlex,
        valueFormatter: isContriColumn
          ? (params: any) => {
              const val = params.value;
              if (val == null) return "";
              const num = parseFloat(val.replace("%", "").trim());
              return isNaN(num) ? val : `${num.toFixed(2)}%`;
            }
          : undefined,
        getQuickFilterText: isContriColumn
          ? (params: any) => {
              const val = params.value;
              return val
                ? parseFloat(val.replace("%", "").trim()).toString()
                : "";
            }
          : undefined,
        comparator: isContriColumn
          ? (a: any, b: any) => {
              const numA = parseFloat((a || "").replace("%", "").trim()) || 0;
              const numB = parseFloat((b || "").replace("%", "").trim()) || 0;
              return numA - numB;
            }
          : undefined,
      };
    });
  }, []);

  const deptColumnDefs = useMemo(
    () => makeCols(departmentData),
    [departmentData, makeCols]
  );
  const branchColumnDefs = useMemo(
    () => makeCols(branchData),
    [branchData, makeCols]
  );
  const itemColumnDefs = useMemo(
    () => makeCols(itemsData),
    [itemsData, makeCols]
  );

  const currentData: any =
    activeTab === "branch"
      ? branchData
      : activeTab === "department"
      ? departmentData
      : itemsData;
  const currentColumnDefs: any =
    activeTab === "branch"
      ? branchColumnDefs
      : activeTab === "department"
      ? deptColumnDefs
      : itemColumnDefs;

  // Displayed columns (Scheme + Display) — unchanged except openLocalModal usage updated
  const displayedColumnDefs = useMemo(() => {
    const cols = Array.isArray(currentColumnDefs) ? [...currentColumnDefs] : [];

    if (activeTab === "item") {
      cols.push(
        {
          field: "Scheme",
          headerName: "Scheme",
          sortable: false,
          resizable: true,
          pinned: "right",
          filter: false,
          lockPosition: false,
          cellRenderer: (params: any) => {
            const savedEntry = findSavedEntryForRow(params.data);
            const hasAppliedScheme = !!savedEntry?.data?.appliedScheme;

            const onApplyClick = (ev: any) => {
              ev.stopPropagation();
              const existing = findSavedEntryForRow(params.data);
              const preset = existing?.data?.appliedScheme ?? {
                startDate: null,
                endDate: null,
                schemeType: null,
                schemeGroup: null,
                displayType: null,
              };

              // Reset handled inside openLocalModal now:
              openLocalModal(
                {
                  title: "Apply New Scheme",
                  size: "lg",
                  content: (
                    <FormProvider {...form}>
                      <form onSubmit={form.handleSubmit(() => {})}>
                        <div className="mb-4 p-3 bg-light rounded border">
                          <div className="d-flex align-items-center mb-2">
                            <div className="me-3 p-2 bg-white rounded border flex-grow-1">
                              <small className="text-muted d-block">
                                Item Code
                              </small>
                              <strong className="text-primary">
                                {params.data["Item Code"] || "N/A"}
                              </strong>
                            </div>
                            <div className="p-2 bg-white rounded border flex-grow-2">
                              <small className="text-muted d-block">
                                Item Name
                              </small>
                              <strong className="text-primary">
                                {params.data["Item Name"] || "N/A"}
                              </strong>
                            </div>
                          </div>
                        </div>

                        <div className="row">
                          {Object.entries(scheme.properties).map(
                            ([key, field]) => (
                              <div key={key} className="col-lg-6 col-md-6 mb-3">
                                {renderFieldWrapper(field as any, key)}
                              </div>
                            )
                          )}
                        </div>
                      </form>
                    </FormProvider>
                  ),
                  footerButtons: [
                    {
                      label: "Close",
                      variant: "secondary",
                      onClick: closeLocalModal,
                    },
                    {
                      label: "Save",
                      variant: "primary",
                      onClick: () =>
                        form.handleSubmit((data: any) => {
                          const existing2 = findSavedEntryForRow(params.data);
                          const existingData2 = existing2?.data ?? {};

                          const schemeToSave = {
                            ...(existingData2.appliedDisplay
                              ? { appliedDisplay: existingData2.appliedDisplay }
                              : {}),
                            appliedScheme: data,
                          };

                          dispatch(
                            saveScheme({
                              row: params.data,
                              scheme: schemeToSave,
                            })
                          );
                          closeLocalModal();
                        })(),
                    },
                  ],
                },
                preset
              );
            };

            const onRemoveApplied = (ev: any) => {
              ev.stopPropagation();
              const itemCode = getItemCodeFromRow(params.data);
              const branchCode = getBranchCodeFromRow(params.data);
              const existing = findSavedEntryForRow(params.data);
              const existingData = existing?.data ?? {};

              if (existing) {
                const newData = { ...existingData };
                delete newData.appliedScheme;

                const hasAnySavedKeys =
                  Object.keys(newData).length > 0 &&
                  Object.keys(newData).some(
                    (k) => !["Item Code", "ItemCode", "item_code"].includes(k)
                  );

                if (hasAnySavedKeys) {
                  dispatch(saveScheme({ row: params.data, scheme: newData }));
                } else if (itemCode) {
                  if (branchCode) {
                    dispatch(
                      removeSavedSchemeByItemCode({
                        itemCode: String(itemCode).trim(),
                        branchCode: String(branchCode).trim(),
                      })
                    );
                  } else {
                    dispatch(
                      removeSavedSchemeByItemCode(String(itemCode).trim())
                    );
                  }
                }
              }
            };

            if (hasAppliedScheme) {
              return (
                <div
                  className="d-flex align-items-center gap-2"
                  onClick={(e) => e.stopPropagation()}
                >
                  <span className="badge bg-success text-white px-3 py-2">
                    Applied
                  </span>
                  <button
                    type="button"
                    title="Remove applied scheme"
                    className="btn btn-sm btn-outline-danger p-1"
                    style={{ lineHeight: 1 }}
                    onClick={onRemoveApplied}
                  >
                    ×
                  </button>
                </div>
              );
            }

            return (
              <button
                className="btn btn-sm btn-outline-primary"
                onClick={onApplyClick}
                type="button"
              >
                Apply
              </button>
            );
          },
          width: 120,
        },
        {
          field: "Display",
          headerName: "Display",
          sortable: false,
          resizable: true,
          pinned: "right",
          filter: false,
          lockPosition: false,
          cellRenderer: (params: any) => {
            const savedEntry = findSavedEntryForRow(params.data);
            const hasAppliedDisplay = !!savedEntry?.data?.appliedDisplay;

            const onDisplayClick = (ev: any) => {
              ev.stopPropagation();
              const existing = findSavedEntryForRow(params.data);
              const preset = existing?.data?.appliedDisplay ?? {
                startDate: null,
                endDate: null,
                displayType: null,
              };

              openLocalModal(
                {
                  title: "Display",
                  size: "lg",
                  content: (
                    <FormProvider {...form}>
                      <form onSubmit={form.handleSubmit(() => {})}>
                        <div className="mb-4 p-3 bg-light rounded border">
                          <div className="d-flex align-items-center mb-2">
                            <div className="me-3 p-2 bg-white rounded border flex-grow-1">
                              <small className="text-muted d-block">
                                Item Code
                              </small>
                              <strong className="text-primary">
                                {params.data["Item Code"] || "N/A"}
                              </strong>
                            </div>
                            <div className="p-2 bg-white rounded border flex-grow-2">
                              <small className="text-muted d-block">
                                Item Name
                              </small>
                              <strong className="text-primary">
                                {params.data["Item Name"] || "N/A"}
                              </strong>
                            </div>
                          </div>
                        </div>

                        <div className="row">
                          {Object.entries(display.properties).map(
                            ([key, field]) => (
                              <div
                                key={key}
                                className="col-lg-12 col-md-12 mb-3"
                              >
                                {renderFieldWrapper(field as any, key)}
                              </div>
                            )
                          )}
                        </div>
                      </form>
                    </FormProvider>
                  ),
                  footerButtons: [
                    {
                      label: "Close",
                      variant: "secondary",
                      onClick: closeLocalModal,
                    },
                    {
                      label: "Save",
                      variant: "primary",
                      onClick: () =>
                        form.handleSubmit((data: any) => {
                          const existing2 = findSavedEntryForRow(params.data);
                          const existingData2 = existing2?.data ?? {};

                          const schemeToSave = {
                            ...(existingData2.appliedScheme
                              ? { appliedScheme: existingData2.appliedScheme }
                              : {}),
                            appliedDisplay: data,
                          };

                          dispatch(
                            saveScheme({
                              row: params.data,
                              scheme: schemeToSave,
                            })
                          );
                          closeLocalModal();
                        })(),
                    },
                  ],
                },
                preset
              );
            };

            const onRemoveAppliedDisplay = (ev: any) => {
              ev.stopPropagation();
              const itemCode = getItemCodeFromRow(params.data);
              const branchCode = getBranchCodeFromRow(params.data);
              const existing = findSavedEntryForRow(params.data);
              const existingData = existing?.data ?? {};

              if (existing) {
                const newData = { ...existingData };
                delete newData.appliedDisplay;

                const hasAnySavedKeys =
                  Object.keys(newData).length > 0 &&
                  Object.keys(newData).some(
                    (k) => !["Item Code", "ItemCode", "item_code"].includes(k)
                  );

                if (hasAnySavedKeys) {
                  dispatch(saveScheme({ row: params.data, scheme: newData }));
                } else if (itemCode) {
                  if (branchCode) {
                    dispatch(
                      removeSavedSchemeByItemCode({
                        itemCode: String(itemCode).trim(),
                        branchCode: String(branchCode).trim(),
                      })
                    );
                  } else {
                    dispatch(
                      removeSavedSchemeByItemCode(String(itemCode).trim())
                    );
                  }
                }
              }
            };

            if (hasAppliedDisplay) {
              return (
                <div
                  className="d-flex align-items-center gap-2"
                  onClick={(e) => e.stopPropagation()}
                >
                  <span className="badge bg-success text-white px-3 py-2">
                    Applied
                  </span>
                  <button
                    type="button"
                    title="Remove applied display"
                    className="btn btn-sm btn-outline-danger p-1"
                    style={{ lineHeight: 1 }}
                    onClick={onRemoveAppliedDisplay}
                  >
                    ×
                  </button>
                </div>
              );
            }

            return (
              <button
                className="btn btn-sm btn-outline-secondary"
                onClick={onDisplayClick}
                type="button"
              >
                Apply
              </button>
            );
          },
          width: 120,
        }
      );
    }

    return cols;
  }, [
    currentColumnDefs,
    activeTab,
    form,
    findSavedEntryForRow,
    getItemCodeFromRow,
    getBranchCodeFromRow,
    renderFieldWrapper,
    dispatch,
  ]);

  // Responsive height effect, drilldown, totals, render — unchanged (kept from your file)
  useEffect(() => {
    const calculateTableHeight = () => {
      const windowHeight = window.innerHeight;
      const windowWidth = window.innerWidth;
      const headerHeight = 150;
      const footerHeight = 10;
      const bottomSpace = 50;
      const minHeight = 400;
      const tabletMinWidth = 768;
      const tabletMaxWidth = 1024;
      let calculatedHeight: number;

      if (windowWidth >= 1200) {
        calculatedHeight =
          windowHeight - headerHeight - footerHeight - bottomSpace;
      } else if (
        windowWidth >= tabletMinWidth &&
        windowWidth <= tabletMaxWidth
      ) {
        const tabletAdjustment = windowWidth < 900 ? 150 : 100;
        calculatedHeight =
          windowHeight - headerHeight - footerHeight - tabletAdjustment;
      } else {
        calculatedHeight = windowHeight - headerHeight - footerHeight - 100;
      }

      dispatch(setTableHeight(`${Math.max(calculatedHeight, minHeight)}px`));
    };

    calculateTableHeight();
    window.addEventListener("resize", calculateTableHeight);
    window.addEventListener("orientationchange", calculateTableHeight);
    return () => {
      window.removeEventListener("resize", calculateTableHeight);
      window.removeEventListener("orientationchange", calculateTableHeight);
    };
  }, [dispatch]);

  const handleDrillDown = (e: any) => {
    const domEvent = e?.event;
    if (domEvent && domEvent.target) {
      const targetEl = domEvent.target as HTMLElement;
      if (
        targetEl.closest("button") ||
        targetEl.closest("a") ||
        targetEl.closest(".no-drill")
      ) {
        return;
      }
    }

    if (!e?.data) return;

    const dept = e.data.Department ?? "";
    const branch = e.data["Branch Code"] ?? "";
    const item = e.data["Item Code"] ?? "";

    if (activeTab === "department" && dept) {
      navigate("/dynamictable/1", { state: { department: dept } });
    } else if (activeTab === "branch" && branch) {
      navigate("/dynamictable/1", { state: { branchCode: branch } });
    } else if (activeTab === "item" && item) {
      navigate("/dynamictable/2", { state: { itemCode: item } });
    }
  };

  // totalSummary, rendering part (same as earlier)
  const totalSummary = useMemo(() => {
    if (!currentData.length) return {};
    const keys = Object.keys(currentData[0]);
    const totals: Record<string, number> = {};

    keys.forEach((k) => {
      if (
        !k.includes("Contri") &&
        !(activeTab === "department" && k === "Department") &&
        !(
          activeTab === "branch" &&
          (k === "Branch Code" || k === "Branch Name" || k === "State")
        ) &&
        !(
          activeTab === "item" &&
          [
            "Department",
            "Item Code",
            "Item Name",
            "Category",
            "Sub Category",
            "Item Status",
            "Desc",
          ].includes(k)
        )
      ) {
        totals[k] = 0;
      }
    });

    currentData.forEach((row: any) => {
      keys.forEach((k) => {
        if (k.includes("Contri")) return;
        const n = toNumber(row[k]);
        if (!Number.isNaN(n)) totals[k] += n;
      });
    });

    Object.keys(totals).forEach((k) => {
      totals[k] = Math.round(totals[k]);
    });

    return totals;
  }, [currentData, activeTab]);

  // RENDER (same as before)
  return (
    <Wrapper header="Summaries" subHeader="Report" ExportR={1}>
      <div className="mb-3">
        {loading && <CenteredLoader />}

        {/* Tabs */}
        <ul className="nav nav-tabs mb-1 pb-1">
          {(["department", "branch", "item"] as const).map((tab) => {
            const labels = {
              department: "Department-wise summary",
              branch: "Branch-wise summary",
              item: "Item-wise summary",
            };
            return (
              <li className="nav-item" key={tab}>
                <button
                  className={`nav-link px-4 py-2 rounded-top ${
                    activeTab === tab
                      ? "active fw-semibold text-primary border-primary"
                      : "text-muted"
                  }`}
                  onClick={() => dispatch(setActiveTab(tab))}
                  style={{
                    border: "none",
                    backgroundColor: "transparent",
                    borderBottom:
                      activeTab === tab
                        ? "2px solid #0d6efd"
                        : "2px solid transparent",
                  }}
                >
                  {labels[tab]}
                </button>
              </li>
            );
          })}
        </ul>

        {/* Active Count + Total Summary */}
        {!loading && !error && currentData.length > 0 && (
          <div className="d-flex flex-wrap gap-2 mb-1 align-items-center">
            <span
              className="badge bg-primary text-white px-3 py-2 rounded-2 fw-medium"
              style={{ fontSize: "0.92rem" }}
            >
              {activeTab === "department"
                ? `${departmentSummaries.length} Department${
                    departmentSummaries.length !== 1 ? "s" : ""
                  }`
                : activeTab === "branch"
                ? `${summaries.length} Branch${
                    summaries.length !== 1 ? "es" : ""
                  }`
                : `${itemsSummaries.length} Item${
                    itemsSummaries.length !== 1 ? "s" : ""
                  }`}
            </span>

            {Object.entries(totalSummary).map(([key, value]) => {
              if (key.includes("Contri")) return null;
              return (
                <span
                  key={key}
                  className="badge bg-light text-dark border px-3 py-2 fw-medium"
                  style={{ fontSize: "0.875rem" }}
                  title={toTitleCase(key)}
                >
                  <strong>{toTitleCase(key)}:</strong> {value.toLocaleString()}
                </span>
              );
            })}
          </div>
        )}

        {/* Loading / Error */}
        {(loading || error) && (
          <div className="mb-3">
            <span
              className={`badge px-3 py-2 rounded-2 ${
                loading ? "bg-info text-white" : "bg-danger text-white"
              }`}
              style={{ fontSize: "0.92rem", fontWeight: 500 }}
            >
              {loading ? "Loading data..." : "Failed to load data"}
            </span>
          </div>
        )}

        {/* Scheme Options Error */}
        {schemeOptionsError && (
          <div className="alert alert-warning small">
            Warning: {schemeOptionsError}
          </div>
        )}

        {/* Empty */}
        {!loading && !error && currentData.length === 0 && (
          <div className="text-center py-4 text-muted">
            No data available for the selected view.
          </div>
        )}

        {/* Table */}
        {!loading && !error && currentData.length > 0 && (
          <div className="border rounded-2 overflow-hidden shadow-sm">
            <GridTable
              rowData={currentData}
              columnDefs={displayedColumnDefs}
              enableEditing={false}
              enableSelection={false}
              height={tableHeight}
              onRowClick={enable != 1 && (handleDrillDown as any)}
              reportHeader={`Phase_3_${activeTab}_Summary`}
            />
          </div>
        )}

        {/* Local Modal */}
        <LocalModal
          isOpen={modalConfig.isOpen}
          onClose={closeLocalModal}
          title={modalConfig.title}
          size={modalConfig.size}
          footerButtons={modalConfig.footerButtons}
        >
          {modalConfig.content}
        </LocalModal>
      </div>
    </Wrapper>
  );
};

export default Phase3Page;
