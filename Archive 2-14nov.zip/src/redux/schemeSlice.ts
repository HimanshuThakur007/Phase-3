import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from './store';

// -------------------------------------------------
//  Types
// -------------------------------------------------
export interface SchemeFormValues {
  schemeType: number | null;
  schemeGroup: number | null;
  // add any other fields that come from the form
}

export interface SavedScheme {
  /** Unique id – we generate it when saving */
  id: string;
  /** The whole grid row that opened the modal */
  row: Record<string, any>;
  /** Values the user typed in the modal */
  form: SchemeFormValues;
  /** Timestamp – handy for UI */
  savedAt: string;
}

// -------------------------------------------------
//  Slice
// -------------------------------------------------
interface SchemeState {
  /** All saved schemes */
  savedSchemes: SavedScheme[];
}

const initialState: SchemeState = {
  savedSchemes: [],
};

export const schemeSlice = createSlice({
  name: 'scheme',
  initialState,
  reducers: {
    /** Save = row + form values */
    saveScheme(
      state,
      action: PayloadAction<{
        row: Record<string, any>;
        form: SchemeFormValues;
      }>
    ) {
      const { row, form } = action.payload;

      // generate a stable id from the primary key(s) of the row
      const primaryKey = row['Item Code'] ?? row['Branch Code'] ?? row['Department'];
      const id = `${primaryKey}-${Date.now()}`;

      const newEntry: SavedScheme = {
        id,
        row,
        form,
        savedAt: new Date().toISOString(),
      };

      // If the same primary key already exists → replace, otherwise push
      const existingIdx = state.savedSchemes.findIndex(
        (s) => s.row['Item Code'] === primaryKey
      );
      if (existingIdx > -1) {
        state.savedSchemes[existingIdx] = newEntry;
      } else {
        state.savedSchemes.push(newEntry);
      }
    },

    /** Delete by id */
    deleteScheme(state, action: PayloadAction<string>) {
      state.savedSchemes = state.savedSchemes.filter(
        (s) => s.id !== action.payload
      );
    },

    /** Optional: clear everything */
    clearAllSchemes(state) {
      state.savedSchemes = [];
    },
  },
});

// -------------------------------------------------
//  Export actions
// -------------------------------------------------
export const { saveScheme, deleteScheme, clearAllSchemes } = schemeSlice.actions;

// -------------------------------------------------
//  Selectors (optional but handy)
// -------------------------------------------------
export const selectSavedSchemes = (state: RootState) => state.scheme.savedSchemes;
export const selectSchemeById =
  (id: string) => (state: RootState) =>
    state.scheme.savedSchemes.find((s:any) => s.id === id);

// -------------------------------------------------
//  Reducer
// -------------------------------------------------
export default schemeSlice.reducer;