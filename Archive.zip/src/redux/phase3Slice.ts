// import { createSlice, PayloadAction } from '@reduxjs/toolkit';


// export interface Phase3State {
//     summaries: any[];
//     departmentSummaries: any[];
//     loading: boolean;
//     error: string | null;
//     activeTab: 'branch' | 'department';
//     tableHeight: string;
// }


// const initialState: Phase3State = {
//     summaries: [],
//     departmentSummaries: [],
//     loading: true,
//     error: null,
//     activeTab: 'department',
//     tableHeight: '550px',
// };


// const phase3Slice = createSlice({
//     name: 'phase3',
//     initialState,
//     reducers: {
//         setSummaries(state, action: PayloadAction<any[]>) {
//             state.summaries = action.payload;
//         },
//         setDepartmentSummaries(state, action: PayloadAction<any[]>) {
//             state.departmentSummaries = action.payload;
//         },
//         setLoading(state, action: PayloadAction<boolean>) {
//             state.loading = action.payload;
//         },
//         setError(state, action: PayloadAction<string | null>) {
//             state.error = action.payload;
//         },
//         setActiveTab(state, action: PayloadAction<'branch' | 'department'>) {
//             state.activeTab = action.payload;
//         },
//         setTableHeight(state, action: PayloadAction<string>) {
//             state.tableHeight = action.payload;
//         },
//         resetState(state) {
//             state.summaries = [];
//             state.departmentSummaries = [];
//             state.loading = false;
//             state.error = null;
//         },
//     },
// });


// export const {
//     setSummaries,
//     setDepartmentSummaries,
//     setLoading,
//     setError,
//     setActiveTab,
//     setTableHeight,
//     resetState,
// } = phase3Slice.actions;


// export default phase3Slice.reducer;

import { createSlice, PayloadAction } from '@reduxjs/toolkit';

// Updated state interface
export interface Phase3State {
    summaries: any[];
    departmentSummaries: any[];
    itemSummaries: any[];        // <-- NEW: Item-level summaries
    loading: boolean;
    error: string | null;
    activeTab: 'branch' | 'department' | 'item'; // <-- Optional: add 'item' tab later
    tableHeight: string;
}

const initialState: Phase3State = {
    summaries: [],
    departmentSummaries: [],
    itemSummaries: [],          // <-- Initialized
    loading: true,
    error: null,
    activeTab: 'department',
    tableHeight: '550px',
};

const phase3Slice = createSlice({
    name: 'phase3',
    initialState,
    reducers: {
        setSummaries(state, action: PayloadAction<any[]>) {
            state.summaries = action.payload;
        },
        setDepartmentSummaries(state, action: PayloadAction<any[]>) {
            state.departmentSummaries = action.payload;
        },
        // NEW ACTION
        setItemSummaries(state, action: PayloadAction<any[]>) {
            state.itemSummaries = action.payload;
        },
        setLoading(state, action: PayloadAction<boolean>) {
            state.loading = action.payload;
        },
        setError(state, action: PayloadAction<string | null>) {
            state.error = action.payload;
        },
        setActiveTab(state, action: PayloadAction<'branch' | 'department' | 'item'>) {
            state.activeTab = action.payload;
        },
        setTableHeight(state, action: PayloadAction<string>) {
            state.tableHeight = action.payload;
        },
        resetState(state) {
            state.summaries = [];
            state.departmentSummaries = [];
            state.itemSummaries = [];     // <-- Reset included
            state.loading = false;
            state.error = null;
        },
    },
});

// Export all actions including the new one
export const {
    setSummaries,
    setDepartmentSummaries,
    setItemSummaries,
    setLoading,
    setError,
    setActiveTab,
    setTableHeight,
    resetState,
} = phase3Slice.actions;

export default phase3Slice.reducer;