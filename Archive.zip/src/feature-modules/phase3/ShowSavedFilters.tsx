// components/ShowSavedFilters.tsx
import React, { useEffect, useState, useCallback } from 'react';

type SavedSummary = { label: string; values: string[] };

const STORAGE_KEY_PREFIX = 'phase3-filter-';

const CONFIG: { key: string; label: string }[] = [
    { key: 'branches', label: 'Branches' },
    { key: 'states', label: 'States' },
    { key: 'stockBucket', label: 'Stock Bucket' },
    { key: 'saleBucket', label: 'Sales Bucket' },
    { key: 'transitQty', label: 'Transit Qty' },
    { key: 'localHbtClass', label: 'Local HBT' },
    { key: 'globalHbtClass', label: 'Global HBT' },
    { key: 'localimport', label: 'Local Import' },
];

/** Convert a persisted item into a displayable label */
const toLabel = (item: any): string | null => {
    if (item == null) return null;
    if (typeof item === 'string' || typeof item === 'number') return String(item);
    if (typeof item === 'object') {
        if ('label' in item && item.label) return String(item.label);
        if ('value' in item && item.value) return String(item.value);
        try { return JSON.stringify(item); } catch { return String(item); }
    }
    return String(item);
};

const readPersistedValue = (key: string): any | null => {
    try {
        const raw = sessionStorage.getItem(STORAGE_KEY_PREFIX + key);
        if (!raw) return null;
        const parsed = JSON.parse(raw);
        // treat empty arrays/objects/empty string as not present
        if (
            parsed == null ||
            (Array.isArray(parsed) && parsed.length === 0) ||
            (typeof parsed === 'object' && !Array.isArray(parsed) && Object.keys(parsed).length === 0) ||
            (typeof parsed === 'string' && parsed.trim() === '')
        ) {
            return null;
        }
        return parsed;
    } catch {
        return null;
    }
};

const buildSummaryFromSession = (): SavedSummary[] => {
    const summary: SavedSummary[] = [];

    CONFIG.forEach(({ key, label }) => {
        const persisted = readPersistedValue(key);
        if (persisted == null) return;

        const arr = Array.isArray(persisted) ? persisted : [persisted];
        const labels = arr.map(toLabel).filter(Boolean) as string[];

        if (labels.length > 0) summary.push({ label, values: labels });
    });

    return summary;
};

const ShowSavedFilters: React.FC = () => {
    const [summary, setSummary] = useState<SavedSummary[]>(() => buildSummaryFromSession());

    const refresh = useCallback(() => setSummary(buildSummaryFromSession()), []);

    useEffect(() => {
        refresh();

        // Listen for storage events (other tabs)
        const onStorage = (e: StorageEvent) => {
            if (!e.key) {
                refresh();
                return;
            }
            if (e.key.startsWith(STORAGE_KEY_PREFIX)) refresh();
        };
        window.addEventListener('storage', onStorage);

        // listen for a custom event to update in the same tab
        const onCustom = () => refresh();
        window.addEventListener('phase3-filters-updated', onCustom as EventListener);

        return () => {
            window.removeEventListener('storage', onStorage);
            window.removeEventListener('phase3-filters-updated', onCustom as EventListener);
        };
    }, [refresh]);

    if (!summary || summary.length === 0) return null;

    return (
        <div className="mb-2">
            {/* Header */}
            <div className="d-flex align-items-center mb-1">
                <h6 className="mb-0 fw-semibold text-muted">
                    <i className="bi bi-funnel me-2" style={{ opacity: 0.7 }}></i>
                    Active Filters
                </h6>
            </div>

            {/* Inline Filter Chips */}
            {summary.length > 0 ? (
                <div className="d-flex flex-wrap gap-2 align-items-center">
                    {summary.map((filter, i) => (
                        <div
                            key={i}
                            className="d-flex align-items-center flex-wrap gap-1 p-2 rounded-2 border"
                            style={{
                                fontSize: '0.825rem',
                                minWidth: '140px',
                                maxWidth: '100%',
                                backgroundColor: '#f8fafc',
                                border: '1px solid #e2e8f0',
                                boxShadow: '0 1px 2px rgba(0,0,0,0.03)',
                            }}
                        >
                            <span
                                className="fw-bold text-nowrap"
                                style={{
                                    fontSize: '0.75rem',
                                    color: '#475569',
                                    marginRight: '6px',
                                }}
                                title={filter.label}
                            >
                                {filter.label}:
                            </span>
                            <div className="d-flex flex-wrap gap-1">
                                {filter.values.map((val, idx) => (
                                    <span
                                        key={idx}
                                        className="px-2 py-1 rounded-1"
                                        style={{
                                            fontSize: '0.75rem',
                                            fontWeight: 500,
                                            backgroundColor: '#dbeafe',
                                            color: '#1d4ed8',
                                            lineHeight: 1.2,
                                            maxWidth: '100%',
                                            overflow: 'hidden',
                                            textOverflow: 'ellipsis',
                                            whiteSpace: 'nowrap',
                                        }}
                                        title={val}
                                    >
                                        {val}
                                    </span>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <p className="text-muted mb-0" style={{ fontSize: '0.875rem' }}>
                    No active filters applied.
                </p>
            )}
        </div>
    );
};

export default ShowSavedFilters;
