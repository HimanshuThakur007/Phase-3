// Pase3DynamicTable.tsx
import React, { useEffect, useMemo } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import Wrapper from "../../common/uicomponent/wrapper";
import GridTable from "../../common/component/GridTable";
import { toTitleCase } from "./helperfunc";
import { useSelector } from "react-redux";
import CenteredLoader from "../../common/component/CenteredLoader";

const Pase3DynamicTable: React.FC = () => {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();

  const selectedDepartment = (location.state as any)?.department ?? "";
  const selectedBranch = (location.state as any)?.branchCode ?? "";
  const itemCode = (location.state as any)?.itemCode ?? "";

  // Redux state
  const {
    data: detailData,
    loading,
    error,
  } = useSelector((state: any) => state.reportDetail);
  const [tableHeight, setTableHeight] = React.useState("550px");

  // -------------------------------------------------
  //  TOTAL CALCULATIONS
  // -------------------------------------------------
  const totals = useMemo(() => {
    if (!detailData?.length) {
      return {
        totalSiteQty: 0,
        totalSaleQty: 0,
        totalSaleVal: 0,
        totalStockValue: 0,
      };
    }

    return detailData.reduce(
      (acc: any, row: any) => {
        const siteQty = row.total_site_qty ?? row.Site_Qtys ?? 0;
        acc.totalSiteQty += typeof siteQty === "number" ? siteQty : 0;

        const saleQty = row.Total_Sale_Qty ?? row.total_sale_qty ?? 0;
        acc.totalSaleQty += typeof saleQty === "number" ? saleQty : 0;

        const saleVal = row.Total_Sale_Val ?? row.total_sale_val ?? 0;
        acc.totalSaleVal += typeof saleVal === "number" ? saleVal : 0;

        const stockVal =
          row.Str_Stk_Sp_Value ??
          row.str_stk_sp_value ??
          row.total_str_stk_sp_value ??
          0;
        acc.totalStockValue += typeof stockVal === "number" ? stockVal : 0;

        return acc;
      },
      {
        totalSiteQty: 0,
        totalSaleQty: 0,
        totalSaleVal: 0,
        totalStockValue: 0,
      }
    );
  }, [detailData]);

  // -------------------------------------------------
  //  COLUMNS
  // -------------------------------------------------
  const columnDefs = useMemo(() => {
    if (!detailData?.length) return [];
    const first = detailData[0];
    const keys = Object.keys(first);

    return keys.map((k) => ({
      field: k,
      headerName: toTitleCase(k),
      filter:
        typeof first[k] === "string"
          ? "agTextColumnFilter"
          : "agNumberColumnFilter",
      headerClass: "bg-royal-blue text-white",
      sortable: true,
      resizable: true,
    }));
  }, [detailData, id]);

  // -------------------------------------------------
  //  RESPONSIVE HEIGHT
  // -------------------------------------------------
  useEffect(() => {
    const calculateTableHeight = () => {
      const windowHeight = window.innerHeight;
      const windowWidth = window.innerWidth;
      const headerHeight = 100;
      const footerHeight = 30;
      const bottomSpace = 50;
      const minHeight = 400;
      const tabletMinWidth = 768;
      const tabletMaxWidth = 1024;
      let calculatedHeight: number;

      if (windowWidth >= 1200) {
        calculatedHeight =
          windowHeight - headerHeight - footerHeight - bottomSpace;
      } else if (
        windowWidth >= tabletMinWidth &&
        windowWidth <= tabletMaxWidth
      ) {
        const tabletAdjustment = windowWidth < 900 ? 150 : 100;
        calculatedHeight =
          windowHeight - headerHeight - footerHeight - tabletAdjustment;
      } else {
        calculatedHeight = windowHeight - headerHeight - footerHeight - 100;
      }

      setTableHeight(`${Math.max(calculatedHeight, minHeight)}px`);
    };

    calculateTableHeight();
    window.addEventListener("resize", calculateTableHeight);
    window.addEventListener("orientationchange", calculateTableHeight);
    return () => {
      window.removeEventListener("resize", calculateTableHeight);
      window.removeEventListener("orientationchange", calculateTableHeight);
    };
  }, []);

  // -------------------------------------------------
  //  DRILL-DOWN TO ITEM LEVEL
  // -------------------------------------------------
  const handleDrillDown = (e: any) => {
    if (id === "2") return;
    const code =
      e.data.Item_Code ?? e.data.item_code ?? e.data["Item Code"] ?? "";
    if (code) {
      navigate("/dynamictable/2", { state: { itemCode: code } });
    }
  };

  const heading = selectedDepartment
    ? `Department: ${selectedDepartment}`
    : selectedBranch
    ? `Branch: ${selectedBranch}`
    : `ItemCode: ${itemCode}`;

  // -------------------------------------------------
  //  RENDER
  // -------------------------------------------------
  return (
    <Wrapper
      header={`Phase 3 – ${heading}`}
      subHeader="Detail Report"
      ExportR={1}
      backButtonName="Back"
    >
      <>
        {loading && <CenteredLoader />}
        {error && <div className="alert alert-danger">{error}</div>}

        {!loading && !error && (
          <>
            {/* ✨ Unified Summary Badges */}
            {detailData.length > 0 && (
              <div className="d-flex flex-wrap gap-2 mb-1 align-items-center">
                {Object.entries({
                  "Site Qty": totals.totalSiteQty,
                  "Sale Qty": totals.totalSaleQty,
                  "Sale Value": totals.totalSaleVal,
                  "Sp Value": totals.totalStockValue,
                }).map(([label, value]) => {
                  const cleanValue = Math.floor(Number(value));
                  const displayValue = cleanValue.toLocaleString("en-IN");

                  return (
                    <span
                      key={label}
                      className="badge bg-light text-dark border px-3 py-2 fw-medium"
                      style={{ fontSize: "0.875rem" }}
                      title={label}
                    >
                      <strong>{label}:</strong> {displayValue}
                    </span>
                  );
                })}
              </div>
            )}

            {/* Table */}
            {detailData.length > 0 ? (
              <GridTable
                rowData={detailData}
                columnDefs={columnDefs}
                enableEditing={false}
                enableSelection={false}
                height={tableHeight}
                onRowClick={handleDrillDown}
                reportHeader={`Phase_3_${heading}_Summary`}
              />
            ) : (
              <div className="text-center py-4 text-muted">
                No data available for the selected view.
              </div>
            )}
          </>
        )}
      </>
    </Wrapper>
  );
};

export default Pase3DynamicTable;
