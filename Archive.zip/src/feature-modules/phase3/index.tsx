import React, { useEffect, useMemo, useCallback, useState } from "react";
import { useNavigate } from "react-router-dom";
import Wrapper from "../../common/uicomponent/wrapper";
import GridTable from "../../common/component/GridTable";
import CenteredLoader from "../../common/component/CenteredLoader";
import { toNumber, toTitleCase } from "./helperfunc";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../redux/store";
import { setActiveTab, setTableHeight } from "../../redux/phase3Slice";

const STORAGE_KEY_PREFIX = "phase3-filter-";

const FILTER_CONFIG = [
  { key: "branches", label: "Branches" },
  { key: "states", label: "States" },
  { key: "stockBucket", label: "Stock Bucket" },
  { key: "saleBucket", label: "Sales Bucket" },
  { key: "transitQty", label: "Transit Qty" },
  { key: "localHbtClass", label: "Local HBT" },
  { key: "globalHbtClass", label: "Global HBT" },
  { key: "localimport", label: "Local Import" },
] as const;

const Phase3Page: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const summaries = useSelector((s: RootState) => s.phase3.summaries);
  const departmentSummaries = useSelector(
    (s: RootState) => s.phase3.departmentSummaries
  );
  const itemsSummaries = useSelector((s: RootState) => s.phase3.itemSummaries);
  const loading = useSelector((s: RootState) => s.phase3.loading);
  const error = useSelector((s: RootState) => s.phase3.error);
  const activeTab = useSelector((s: RootState) => s.phase3.activeTab);
  const tableHeight = useSelector((s: RootState) => s.phase3.tableHeight);

  // -------------------------------------------------
  //  ACTIVE FILTERS (DATA ONLY)
  // -------------------------------------------------
  const [filterRefresh, setFilterRefresh] = useState(0);

  const activeFilters = useMemo(() => {
    const filters: { label: string; values: string[] }[] = [];

    FILTER_CONFIG.forEach(({ key, label }) => {
      const raw = sessionStorage.getItem(STORAGE_KEY_PREFIX + key);
      if (!raw) return;

      try {
        const parsed = JSON.parse(raw);
        const arr = Array.isArray(parsed) ? parsed : [parsed];
        const values = arr
          .map((item) => {
            if (!item) return null;
            if (typeof item === "string" || typeof item === "number")
              return String(item);
            return item.label ?? item.value ?? null;
          })
          .filter(Boolean)
          .map(String);

        if (values.length > 0) {
          filters.push({ label, values });
        }
      } catch (e) {
        // ignore invalid JSON
      }
    });

    return filters;
  }, [filterRefresh]);

  // Listen for filter updates in same tab
  useEffect(() => {
    const handler = () => setFilterRefresh((prev) => prev + 1);
    window.addEventListener("phase3-filters-updated", handler);
    return () => window.removeEventListener("phase3-filters-updated", handler);
  }, []);

  // -------------------------------------------------
  //  TRANSFORMED DATA
  // -------------------------------------------------
  const departmentData = useMemo(
    () =>
      departmentSummaries.map((d: any) => ({
        Department: d?.department,
        "Str Stk": Math.round(d?.total_site_quantity || 0),
        "Stk Val": Math.round(d?.total_str_stk_sp_value || 0),
        "Sale Qty": Math.round(d?.total_sale_quantity || 0),
        "Sale Val": Math.round(d?.total_sale_value || 0),
        "Stk Qty Contri": `${Number(d?.stock_qty_contri).toFixed(2)}%`,
        "Stk Val Contri": `${Number(d?.stock_val_contri).toFixed(2)}%`,
      })),
    [departmentSummaries]
  );

  const branchData = useMemo(
    () =>
      summaries.map((d: any) => ({
        "Branch Code": d?.branch_code,
        "Branch Name": d?.branch_name,
        State: d?.state,
        "Str Stk": Math.round(d?.total_site_quantity || 0),
        "Stk Val": Math.round(d?.total_str_stk_sp_value || 0),
        "Sale Qty": Math.round(d?.total_sale_quantity || 0),
        "Sale Val": Math.round(d?.total_sale_value || 0),
        "Stk Qty Contri": `${Number(d?.stock_qty_contri).toFixed(2)}%`,
        "Stk Val Contri": `${Number(d?.stock_val_contri).toFixed(2)}%`,
      })),
    [summaries]
  );

  const itemsData = useMemo(
    () =>
      itemsSummaries.map((d: any) => ({
        "Item Code": d?.item_code,
        "Item Name": d?.item_name,
        Department: d?.department,
        Category: d?.category,
        "Sub Category": d?.subcategory,
        "Item Status": d?.active_inactive,
        Desc: d?.item_desc,
        "Str Stk": Math.round(d?.total_site_quantity || 0),
        "Sale Qty": Math.round(d?.total_sale_quantity || 0),
        "Sale Val": Math.round(d?.total_sale_value || 0),
        "Stk Val": Math.round(d?.total_str_stk_sp_value || 0),
        "Stk Qty Contri": `${Number(d?.stock_qty_contri).toFixed(2)}%`,
        "Stk Val Contri": `${Number(d?.stock_val_contri).toFixed(2)}%`,
      })),
    [itemsSummaries]
  );

  // -------------------------------------------------
  //  COLUMN DEFINITIONS
  // -------------------------------------------------
  const makeCols = useCallback((data: any[]) => {
    if (!data.length) return [];
    const first = data[0];
    const allKeys = Object.keys(first);
    const totalColumns = allKeys.length;
    const defaultFlex = totalColumns <= 7 ? 1 : 0;

    return allKeys.map((k) => {
      const isContriColumn = k === "Stk Qty Contri" || k === "Stk Val Contri";

      return {
        field: k,
        headerName: toTitleCase(k),
        sortable: true,
        resizable: true,
        filter:
          typeof first[k] === "string"
            ? "agTextColumnFilter"
            : "agNumberColumnFilter",
        pinned: isContriColumn ? "right" : null,
        lockPosition: isContriColumn,
        cellStyle: isContriColumn ? { textAlign: "right" } : undefined,
        flex: isContriColumn ? 0 : defaultFlex,
        valueFormatter: isContriColumn
          ? (params: any) => {
              const val = params.value;
              if (val == null) return "";
              const num = parseFloat(val.replace("%", "").trim());
              return isNaN(num) ? val : `${num.toFixed(2)}%`;
            }
          : undefined,
        getQuickFilterText: isContriColumn
          ? (params: any) => {
              const val = params.value;
              return val
                ? parseFloat(val.replace("%", "").trim()).toString()
                : "";
            }
          : undefined,
        comparator: isContriColumn
          ? (a: any, b: any) => {
              const numA = parseFloat((a || "").replace("%", "").trim()) || 0;
              const numB = parseFloat((b || "").replace("%", "").trim()) || 0;
              return numA - numB;
            }
          : undefined,
      };
    });
  }, []);

  const deptColumnDefs = useMemo(
    () => makeCols(departmentData),
    [departmentData, makeCols]
  );
  const branchColumnDefs = useMemo(
    () => makeCols(branchData),
    [branchData, makeCols]
  );
  const itemColumnDefs = useMemo(
    () => makeCols(itemsData),
    [itemsData, makeCols]
  );

  const currentData: any =
    activeTab === "branch"
      ? branchData
      : activeTab === "department"
      ? departmentData
      : itemsData;
  const currentColumnDefs: any =
    activeTab === "branch"
      ? branchColumnDefs
      : activeTab === "department"
      ? deptColumnDefs
      : itemColumnDefs;

  // -------------------------------------------------
  //  RESPONSIVE HEIGHT
  // -------------------------------------------------
  useEffect(() => {
    const calculateTableHeight = () => {
      const windowHeight = window.innerHeight;
      const windowWidth = window.innerWidth;
      const headerHeight = 150;
      const footerHeight = 10;
      const bottomSpace = 50;
      const minHeight = 400;
      const tabletMinWidth = 768;
      const tabletMaxWidth = 1024;
      let calculatedHeight: number;

      if (windowWidth >= 1200) {
        calculatedHeight =
          windowHeight - headerHeight - footerHeight - bottomSpace;
      } else if (
        windowWidth >= tabletMinWidth &&
        windowWidth <= tabletMaxWidth
      ) {
        const tabletAdjustment = windowWidth < 900 ? 150 : 100;
        calculatedHeight =
          windowHeight - headerHeight - footerHeight - tabletAdjustment;
      } else {
        calculatedHeight = windowHeight - headerHeight - footerHeight - 100;
      }

      dispatch(setTableHeight(`${Math.max(calculatedHeight, minHeight)}px`));
    };

    calculateTableHeight();
    window.addEventListener("resize", calculateTableHeight);
    window.addEventListener("orientationchange", calculateTableHeight);
    return () => {
      window.removeEventListener("resize", calculateTableHeight);
      window.removeEventListener("orientationchange", calculateTableHeight);
    };
  }, [dispatch]);

  // -------------------------------------------------
  //  DRILL-DOWN
  // -------------------------------------------------
  const handleDrillDown = (e: any) => {
    if (!e?.data) return;

    const dept = e.data.Department ?? "";
    const branch = e.data["Branch Code"] ?? "";
    const item = e.data["Item Code"] ?? "";

    if (activeTab === "department" && dept) {
      navigate("/dynamictable/1", { state: { department: dept } });
    } else if (activeTab === "branch" && branch) {
      navigate("/dynamictable/1", { state: { branchCode: branch } });
    } else if (activeTab === "item" && item) {
      navigate("/dynamictable/2", { state: { itemCode: item } });
    }
  };

  // -------------------------------------------------
  //  TOTAL SUMMARY
  // -------------------------------------------------
  const totalSummary = useMemo(() => {
    if (!currentData.length) return {};

    const keys = Object.keys(currentData[0]);
    const totals: Record<string, number> = {};

    keys.forEach((k) => {
      if (
        !k.includes("Contri") &&
        !(activeTab === "department" && k === "Department") &&
        !(
          activeTab === "branch" &&
          (k === "Branch Code" || k === "Branch Name" || k === "State")
        ) &&
        !(
          activeTab === "item" &&
          (k === "Department" ||
            k === "Item Code" ||
            k === "Item Name" ||
            k === "Category" ||
            k === "Sub Category" ||
            k === "Item Status" ||
            k === "Desc")
        )
      ) {
        totals[k] = 0;
      }
    });

    currentData.forEach((row: any) => {
      keys.forEach((k) => {
        if (k.includes("Contri")) return;
        if (activeTab === "department" && k === "Department") return;
        if (
          activeTab === "branch" &&
          (k === "Branch Code" || k === "Branch Name" || k === "State")
        )
          return;
        if (
          activeTab === "item" &&
          (k === "Department" ||
            k === "Item Code" ||
            k === "Item Name" ||
            k === "Category" ||
            k === "Sub Category" ||
            k === "Item Status" ||
            k === "Desc")
        )
          return;

        const n = toNumber(row[k]);
        if (!Number.isNaN(n)) totals[k] += n;
      });
    });

    Object.keys(totals).forEach((k) => {
      totals[k] = Math.round(totals[k]);
    });

    return totals;
  }, [currentData, activeTab]);

  console.log("Active Filterss", activeFilters);

  // -------------------------------------------------
  //  RENDER
  // -------------------------------------------------
  return (
    <Wrapper header="Summaries" subHeader="Report" ExportR={1}>
      <div className="mb-3">
        {loading && <CenteredLoader />}

        {/* Tabs */}
        <ul className="nav nav-tabs mb-1 pb-1">
          {(["department", "branch", "item"] as const).map((tab) => {
            const labels = {
              department: "Department-wise summary",
              branch: "Branch-wise summary",
              item: "Item-wise summary",
            };
            return (
              <li className="nav-item" key={tab}>
                <button
                  className={`nav-link px-4 py-2 rounded-top ${
                    activeTab === tab
                      ? "active fw-semibold text-primary border-primary"
                      : "text-muted"
                  }`}
                  onClick={() => dispatch(setActiveTab(tab))}
                  style={{
                    border: "none",
                    backgroundColor: "transparent",
                    borderBottom:
                      activeTab === tab
                        ? "2px solid #0d6efd"
                        : "2px solid transparent",
                  }}
                >
                  {labels[tab]}
                </button>
              </li>
            );
          })}
        </ul>

        {/* Active Count + Total Summary */}
        {!loading && !error && currentData.length > 0 && (
          <div className="d-flex flex-wrap gap-2 mb-1 align-items-center">
            <span
              className="badge bg-primary text-white px-3 py-2 rounded-2 fw-medium"
              style={{ fontSize: "0.92rem" }}
            >
              {activeTab === "department"
                ? `${departmentSummaries.length} Department${
                    departmentSummaries.length !== 1 ? "s" : ""
                  }`
                : activeTab === "branch"
                ? `${summaries.length} Branch${
                    summaries.length !== 1 ? "es" : ""
                  }`
                : `${itemsSummaries.length} Item${
                    itemsSummaries.length !== 1 ? "s" : ""
                  }`}
            </span>

            {Object.entries(totalSummary).map(([key, value]) => {
              if (key.includes("Contri")) return null;
              return (
                <span
                  key={key}
                  className="badge bg-light text-dark border px-3 py-2 fw-medium"
                  style={{ fontSize: "0.875rem" }}
                  title={toTitleCase(key)}
                >
                  <strong>{toTitleCase(key)}:</strong> {value.toLocaleString()}
                </span>
              );
            })}
          </div>
        )}

        {/* Loading / Error */}
        {(loading || error) && (
          <div className="mb-3">
            <span
              className={`badge px-3 py-2 rounded-2 ${
                loading ? "bg-info text-white" : "bg-danger text-white"
              }`}
              style={{ fontSize: "0.92rem", fontWeight: 500 }}
            >
              {loading ? "Loading data..." : "Failed to load data"}
            </span>
          </div>
        )}

        {/* Empty */}
        {!loading && !error && currentData.length === 0 && (
          <div className="text-center py-4 text-muted">
            No data available for the selected view.
          </div>
        )}

        {/* Table */}
        {!loading && !error && currentData.length > 0 && (
          <div className="border rounded-2 overflow-hidden shadow-sm">
            <GridTable
              rowData={currentData}
              columnDefs={currentColumnDefs}
              enableEditing={false}
              enableSelection={false}
              height={tableHeight}
              onRowClick={handleDrillDown}
              reportHeader={`Phase_3_${activeTab}_Summary`}
              //   leftHeaders={activeFilters} // Only data
            />
          </div>
        )}
      </div>
    </Wrapper>
  );
};

export default Phase3Page;
