export interface AuthResponse {
    msg: string;
    status: number;
    responseBodyEncrypted: unknown;
    got: any
  }